#include "ui/filemanager/filemanager_app.h"
#include <cstdio>

int main(int argc, char** argv) {
    printf("[AgroOS] File Manager starting...\n");
    agro::FileManagerApp app;
    if (!app.initialize()) {
        fprintf(stderr, "Failed to initialize File Manager\n");
        return 1;
    }
    app.runEventLoop();
    printf("[AgroOS] File Manager exiting.\n");
    return 0;
}
