# AgroOS UI Framework

Professional C++ UI Framework for AgroOS Desktop Environment.

## Architecture

```
ui/
├── common/
│   ├── agro_math.h          # Vec2, Rect, Color helpers
│   ├── agro_appwindow.h/.cpp # Wayland window base (titlebar, acrylic, shadow)
│   ├── agro_widgets.h/.cpp   # UI widgets (Button, Switch, Slider, Input, etc.)
│   └── agro_layout.h/.cpp    # Flex, Grid, Sidebar layouts
├── filemanager/
│   ├── filemanager_app.h/.cpp # File Manager application
└── settings/
    └── settings_app.h/.cpp    # Settings application
```

## Build Requirements

- CMake 3.16+
- C++17 compiler (GCC 9+ / Clang 10+)
- Wayland development libraries
- Skia (prebuilt)

## Build

```bash
mkdir build && cd build
cmake ..
make -j$(nproc)
```

## Run

```bash
./agro-filemanager
./agro-settings
```

## Design Language

- **Acrylic/Glassmorphism** panels with semi-transparent backgrounds
- **12px rounded corners** on windows and cards
- **Drop shadows** for depth
- **Smooth animations** (easeOutCubic) for startup and view transitions
- **Skia 2D GPU Canvas** for hardware-accelerated rendering
