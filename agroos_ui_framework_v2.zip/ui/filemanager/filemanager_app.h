#pragma once

#include <filesystem>
#include <vector>
#include <string>
#include <memory>
#include <chrono>

#include "../common/agro_appwindow.h"
#include "../common/agro_widgets.h"
#include "../common/agro_layout.h"

namespace agro {
namespace fs = std::filesystem;

// =============================================================================
// FileManagerApp: Wayland pencereli dosya yöneticisi
// =============================================================================
class FileManagerApp : public AppWindow {
public:
    FileManagerApp();
    ~FileManagerApp() override = default;

    void onPaint(SkCanvas* canvas) override;
    bool onMouseMove(int x, int y) override;
    bool onMouseDown(int x, int y, int button) override;
    bool onMouseUp(int x, int y, int button) override;
    bool onMouseScroll(int dx, int dy) override;
    void onWindowResize(int width, int height) override;

private:
    void setupUI();
    void refreshDirectory();
    void navigateTo(const fs::path& path);
    void goBack();
    void goUp();
    void goHome();
    void toggleHiddenFiles();
    void setSortMode(int mode); // 0=name, 1=date, 2=size
    void applySearchFilter();
    void createNewFolder();
    void deleteSelectedItems();
    void copySelectedItems();
    void pasteItems();
    void showProperties();
    void updateBreadcrumb();
    void updateLayout();

    // UI Sections
    void drawSidebar(SkCanvas* canvas);
    void drawToolbar(SkCanvas* canvas);
    void drawFileGrid(SkCanvas* canvas);
    void drawStatusBar(SkCanvas* canvas);
    void drawContextMenu(SkCanvas* canvas);

    // Data
    fs::path currentPath_;
    fs::path homePath_;
    std::vector<fs::path> history_;
    size_t historyIndex_ = 0;
    bool showHidden_ = false;
    int sortMode_ = 0; // 0=name, 1=date, 2=size
    bool gridView_ = true;

    struct FileEntry {
        fs::path path;
        std::string name;
        bool isDirectory;
        uint64_t size;
        fs::file_time_type modified;
        bool selected;
    };
    std::vector<FileEntry> entries_;
    std::vector<FileEntry> filteredEntries_;

    // UI Widgets
    std::shared_ptr<UIContainer> rootContainer_;
    std::shared_ptr<UIContainer> sidebarContainer_;
    std::shared_ptr<UIContainer> toolbarContainer_;
    std::shared_ptr<UIContainer> fileGridContainer_;
    std::shared_ptr<UIContainer> statusContainer_;
    std::shared_ptr<UIContextMenu> contextMenu_;
    std::shared_ptr<UITextInput> searchInput_;
    std::vector<std::shared_ptr<UISidebarItem>> sidebarItems_;
    std::vector<std::shared_ptr<UIFileItem>> fileItems_;
    std::vector<std::shared_ptr<UIIconButton>> toolbarButtons_;
    std::vector<std::shared_ptr<UIButton>> breadcrumbButtons_;

    // Layouts
    SidebarLayout sidebarLayout_;
    GridLayout gridLayout_;
    FlexLayout toolbarLayout_;
    FlexLayout breadcrumbLayout_;

    // Scroll
    float scrollOffsetY_ = 0;
    float maxScrollY_ = 0;

    // Selection
    int hoveredFileIndex_ = -1;
    std::vector<fs::path> clipboard_;
    bool clipboardIsCut_ = false;

    // Animation
    float startupSlide_ = 0;
    float startupOpacity_ = 0;
    std::chrono::steady_clock::time_point startupTime_;
};

} // namespace agro
