#include "filemanager_app.h"
#include <algorithm>
#include <cstring>
#include <pwd.h>
#include <unistd.h>

namespace agro {

static std::string formatFileSize(uint64_t bytes) {
    const char* units[] = {"B", "KB", "MB", "GB", "TB"};
    int unit = 0;
    double size = static_cast<double>(bytes);
    while (size >= 1024.0 && unit < 4) { size /= 1024.0; unit++; }
    char buf[32];
    snprintf(buf, sizeof(buf), "%.1f %s", size, units[unit]);
    return buf;
}

static std::string formatTime(fs::file_time_type tp) {
    auto sctp = std::chrono::time_point_cast<std::chrono::system_clock::time_point>(tp);
    auto t = std::chrono::system_clock::to_time_t(sctp);
    char buf[64];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M", localtime(&t));
    return buf;
}

static std::string homeDir() {
    const char* home = getenv("HOME");
    if (home) return home;
    struct passwd* pw = getpwuid(getuid());
    return pw ? pw->pw_dir : "/";
}

// =============================================================================
// Constructor
// =============================================================================
FileManagerApp::FileManagerApp()
    : AppWindow("File Manager", 1100, 720),
      currentPath_(homeDir()), homePath_(homeDir()),
      startupTime_(std::chrono::steady_clock::now()) {
    setupUI();
    refreshDirectory();
}

// =============================================================================
// UI Setup
// =============================================================================
void FileManagerApp::setupUI() {
    rootContainer_ = std::make_shared<UIContainer>();
    sidebarContainer_ = std::make_shared<UIContainer>();
    toolbarContainer_ = std::make_shared<UIContainer>();
    fileGridContainer_ = std::make_shared<UIContainer>();
    statusContainer_ = std::make_shared<UIContainer>();
    contextMenu_ = std::make_shared<UIContextMenu>();
    contextMenu_->visible = false;

    // Sidebar items
    struct SideItem { const char* icon; const char* label; const char* path; };
    SideItem sides[] = {
        {"🏠", "Home", homeDir().c_str()},
        {"📄", "Documents", (homeDir() + "/Documents").c_str()},
        {"⬇️", "Downloads", (homeDir() + "/Downloads").c_str()},
        {"🖼️", "Pictures", (homeDir() + "/Pictures").c_str()},
        {"🎵", "Music", (homeDir() + "/Music").c_str()},
        {"🎬", "Videos", (homeDir() + "/Videos").c_str()},
        {"💻", "System", "/"},
    };

    for (const auto& si : sides) {
        auto item = std::make_shared<UISidebarItem>();
        item->iconUnicode = si.icon;
        item->label = si.label;
        item->bounds = Rect(0, 0, 200, 40);
        std::string p = si.path;
        item->onClick = [this, p]() { navigateTo(p); };
        sidebarItems_.push_back(item);
        sidebarContainer_->addChild(item);
    }
    sidebarItems_[0]->isSelected = true;

    // Toolbar buttons
    struct TB { const char* icon; std::function<void()> action; };
    TB tbs[] = {
        {"◀", [this]() { goBack(); }},
        {"▶", [this]() { if (historyIndex_ + 1 < history_.size()) { historyIndex_++; navigateTo(history_[historyIndex_]); } }},
        {"⬆", [this]() { goUp(); }},
        {"🔄", [this]() { refreshDirectory(); }},
        {"📁+", [this]() { createNewFolder(); }},
        {"📋", [this]() { copySelectedItems(); }},
        {"📂", [this]() { pasteItems(); }},
        {"🗑️", [this]() { deleteSelectedItems(); }},
        {"≡", [this]() { setSortMode((sortMode_ + 1) % 3); }},
        {"⊞", [this]() { gridView_ = !gridView_; updateLayout(); }},
    };

    for (const auto& tb : tbs) {
        auto btn = std::make_shared<UIIconButton>();
        btn->icon = tb.icon;
        btn->bounds = Rect(0, 0, 36, 36);
        btn->onClick = tb.action;
        toolbarButtons_.push_back(btn);
        toolbarContainer_->addChild(btn);
    }

    // Search input
    searchInput_ = std::make_shared<UITextInput>();
    searchInput_->placeholder = "Search files...";
    searchInput_->bounds = Rect(0, 0, 220, 36);
    searchInput_->onChange = [this](const std::string&) { applySearchFilter(); };
    toolbarContainer_->addChild(searchInput_);

    // Breadcrumb buttons (dynamic)
    updateBreadcrumb();

    // Context menu
    contextMenu_->items = {
        {"New Folder", "Ctrl+Shift+N", false, true, [this]() { createNewFolder(); }},
        {"", "", true, true, nullptr},
        {"Copy", "Ctrl+C", false, true, [this]() { copySelectedItems(); }},
        {"Paste", "Ctrl+V", false, true, [this]() { pasteItems(); }},
        {"Delete", "Del", false, true, [this]() { deleteSelectedItems(); }},
        {"", "", true, true, nullptr},
        {"Properties", "Alt+Enter", false, true, [this]() { showProperties(); }},
    };

    rootContainer_->addChild(sidebarContainer_);
    rootContainer_->addChild(toolbarContainer_);
    rootContainer_->addChild(fileGridContainer_);
    rootContainer_->addChild(statusContainer_);
    rootContainer_->addChild(contextMenu_);

    sidebarLayout_.sidebarWidth = bounds_.width * 0.22f;
    gridLayout_.columns = 6;
    gridLayout_.itemWidth = 96;
    gridLayout_.itemHeight = 120;
    gridLayout_.gapX = 16;
    gridLayout_.gapY = 16;
    gridLayout_.padding = 16;
}

// =============================================================================
// Directory Operations
// =============================================================================
void FileManagerApp::refreshDirectory() {
    entries_.clear();
    try {
        for (const auto& entry : fs::directory_iterator(currentPath_, fs::directory_options::skip_permission_denied)) {
            if (!showHidden_ && entry.path().filename().string()[0] == '.') continue;
            FileEntry fe;
            fe.path = entry.path();
            fe.name = entry.path().filename().string();
            fe.isDirectory = entry.is_directory();
            fe.size = fe.isDirectory ? 0 : entry.file_size();
            fe.modified = entry.last_write_time();
            fe.selected = false;
            entries_.push_back(fe);
        }
    } catch (...) {}

    // Sort
    if (sortMode_ == 0) {
        std::sort(entries_.begin(), entries_.end(),
            [](const FileEntry& a, const FileEntry& b) {
                if (a.isDirectory != b.isDirectory) return a.isDirectory > b.isDirectory;
                return a.name < b.name;
            });
    } else if (sortMode_ == 1) {
        std::sort(entries_.begin(), entries_.end(),
            [](const FileEntry& a, const FileEntry& b) {
                if (a.isDirectory != b.isDirectory) return a.isDirectory > b.isDirectory;
                return a.modified > b.modified;
            });
    } else {
        std::sort(entries_.begin(), entries_.end(),
            [](const FileEntry& a, const FileEntry& b) {
                if (a.isDirectory != b.isDirectory) return a.isDirectory > b.isDirectory;
                return a.size > b.size;
            });
    }

    applySearchFilter();
    updateBreadcrumb();
}

void FileManagerApp::navigateTo(const fs::path& path) {
    if (!fs::exists(path) || !fs::is_directory(path)) return;
    currentPath_ = fs::canonical(path);
    if (historyIndex_ + 1 < history_.size()) {
        history_.resize(historyIndex_ + 1);
    }
    history_.push_back(currentPath_);
    historyIndex_ = history_.size() - 1;
    refreshDirectory();
}

void FileManagerApp::goBack() {
    if (historyIndex_ > 0) {
        historyIndex_--;
        currentPath_ = history_[historyIndex_];
        refreshDirectory();
    }
}

void FileManagerApp::goUp() {
    fs::path parent = currentPath_.parent_path();
    if (!parent.empty() && parent != currentPath_) {
        navigateTo(parent);
    }
}

void FileManagerApp::goHome() {
    navigateTo(homePath_);
}

void FileManagerApp::toggleHiddenFiles() {
    showHidden_ = !showHidden_;
    refreshDirectory();
}

void FileManagerApp::setSortMode(int mode) {
    sortMode_ = mode;
    refreshDirectory();
}

void FileManagerApp::applySearchFilter() {
    filteredEntries_ = entries_;
    std::string query = searchInput_->text;
    if (!query.empty()) {
        filteredEntries_.erase(
            std::remove_if(filteredEntries_.begin(), filteredEntries_.end(),
                [&query](const FileEntry& e) {
                    return e.name.find(query) == std::string::npos;
                }), filteredEntries_.end());
    }

    // Rebuild file items
    fileItems_.clear();
    fileGridContainer_->clearChildren();
    for (auto& fe : filteredEntries_) {
        auto item = std::make_shared<UIFileItem>();
        item->filename = fe.name;
        item->isDirectory = fe.isDirectory;
        item->isSelected = fe.selected;
        item->fileSize = fe.size;
        item->onDoubleClick = [this, &fe]() {
            if (fe.isDirectory) navigateTo(fe.path);
        };
        item->onRightClick = [this]() {
            contextMenu_->show(mouseX_, mouseY_);
        };
        fileItems_.push_back(item);
        fileGridContainer_->addChild(item);
    }
    updateLayout();
}

void FileManagerApp::createNewFolder() {
    fs::path newPath = currentPath_ / "New Folder";
    int suffix = 1;
    while (fs::exists(newPath)) {
        newPath = currentPath_ / ("New Folder (" + std::to_string(suffix) + ")");
        suffix++;
    }
    try { fs::create_directory(newPath); } catch (...) {}
    refreshDirectory();
}

void FileManagerApp::deleteSelectedItems() {
    for (auto& fe : entries_) {
        if (fe.selected) {
            try {
                if (fe.isDirectory) fs::remove_all(fe.path);
                else fs::remove(fe.path);
            } catch (...) {}
        }
    }
    refreshDirectory();
}

void FileManagerApp::copySelectedItems() {
    clipboard_.clear();
    clipboardIsCut_ = false;
    for (const auto& fe : entries_) {
        if (fe.selected) clipboard_.push_back(fe.path);
    }
}

void FileManagerApp::pasteItems() {
    for (const auto& src : clipboard_) {
        fs::path dest = currentPath_ / src.filename();
        try {
            if (clipboardIsCut_) fs::rename(src, dest);
            else if (fs::is_directory(src)) fs::copy(src, dest, fs::copy_options::recursive);
            else fs::copy(src, dest);
        } catch (...) {}
    }
    if (clipboardIsCut_) clipboard_.clear();
    refreshDirectory();
}

void FileManagerApp::showProperties() {
    // Properties dialog would be implemented here
}

// =============================================================================
// Breadcrumb
// =============================================================================
void FileManagerApp::updateBreadcrumb() {
    breadcrumbButtons_.clear();
    fs::path p = currentPath_;
    std::vector<fs::path> parts;
    while (!p.empty() && p != "/") {
        parts.push_back(p);
        p = p.parent_path();
    }
    if (currentPath_ != "/") parts.push_back("/");
    std::reverse(parts.begin(), parts.end());

    for (const auto& part : parts) {
        auto btn = std::make_shared<UIButton>();
        btn->text = (part == "/") ? "Home" : part.filename().string();
        btn->bounds = Rect(0, 0, measureText(btn->text, 13) + 24, 32);
        btn->cornerRadius = 6;
        btn->bgColor = Color::fromHex(0xFFFFFF, 60);
        btn->hoverColor = Color::HoverBg();
        fs::path target = part;
        btn->onClick = [this, target]() { navigateTo(target); };
        breadcrumbButtons_.push_back(btn);
        toolbarContainer_->addChild(btn);
    }
}

// =============================================================================
// Layout
// =============================================================================
void FileManagerApp::updateLayout() {
    float sidebarW = bounds_.width * 0.22f;
    float toolbarH = 56;
    float statusH = 28;
    float contentY = kTitleBarHeight + toolbarH;
    float contentH = bounds_.height - contentY - statusH;

    sidebarContainer_->bounds = Rect(0, kTitleBarHeight, sidebarW, bounds_.height - kTitleBarHeight);
    toolbarContainer_->bounds = Rect(sidebarW, kTitleBarHeight, bounds_.width - sidebarW, toolbarH);
    fileGridContainer_->bounds = Rect(sidebarW, contentY, bounds_.width - sidebarW, contentH);
    statusContainer_->bounds = Rect(sidebarW, bounds_.height - statusH, bounds_.width - sidebarW, statusH);

    // Sidebar items vertical layout
    float sy = 16;
    for (auto& si : sidebarItems_) {
        si->bounds = Rect(8, sy, sidebarW - 16, 36);
        sy += 40;
    }

    // Toolbar layout
    float tx = 12;
    for (auto& btn : toolbarButtons_) {
        btn->bounds = Rect(tx, 10, 36, 36);
        tx += 40;
    }
    // Breadcrumb after buttons
    tx += 8;
    for (auto& bc : breadcrumbButtons_) {
        bc->bounds = Rect(tx, 12, bc->bounds.w, 32);
        tx += bc->bounds.w + 4;
    }
    // Search at right
    searchInput_->bounds = Rect(toolbarContainer_->bounds.right() - 240, 10, 220, 36);

    // File grid
    if (gridView_) {
        gridLayout_.columns = std::max(1, (int)((fileGridContainer_->bounds.w - 32) / 112));
        gridLayout_.apply(fileGridContainer_->bounds, fileGridContainer_->children);
    } else {
        // List view
        float ly = fileGridContainer_->bounds.y + 8;
        for (auto& child : fileGridContainer_->children) {
            child->bounds = Rect(fileGridContainer_->bounds.x + 16, ly,
                                 fileGridContainer_->bounds.w - 32, 48);
            ly += 52;
        }
    }
}

void FileManagerApp::onWindowResize(int width, int height) {
    AppWindow::onWindowResize(width, height);
    updateLayout();
}

// =============================================================================
// Drawing
// =============================================================================
void FileManagerApp::onPaint(SkCanvas* canvas) {
    // Startup animation
    auto now = std::chrono::steady_clock::now();
    float ms = std::chrono::duration<float, std::milli>(now - startupTime_).count();
    float t = std::min(1.0f, ms / 500.0f);
    startupOpacity_ = easeOutCubic(t);
    startupSlide_ = (1.0f - easeOutCubic(t)) * 20.0f;

    canvas->save();
    canvas->translate(0, startupSlide_);

    // Sidebar background (acrylic)
    SkPaint sidebarPaint;
    sidebarPaint.setAntiAlias(true);
    sidebarPaint.setColor(Color::AcrylicSidebar().toSkia());
    canvas->drawRect(SkRect::MakeXYWH(0, kTitleBarHeight, sidebarContainer_->bounds.w,
                                      bounds_.height - kTitleBarHeight), sidebarPaint);

    // Sidebar border
    SkPaint border;
    border.setColor(Color::Border().toSkia());
    border.setStrokeWidth(1);
    canvas->drawLine(sidebarContainer_->bounds.right(), kTitleBarHeight,
                     sidebarContainer_->bounds.right(), bounds_.height, border);

    // Toolbar bg
    SkPaint toolbarBg;
    toolbarBg.setColor(Color::fromHex(0xFFFFFF, 40).toSkia());
    canvas->drawRect(SkRect::MakeXYWH(toolbarContainer_->bounds.x, kTitleBarHeight,
                                      toolbarContainer_->bounds.w, toolbarContainer_->bounds.h), toolbarBg);

    // Toolbar bottom border
    canvas->drawLine(toolbarContainer_->bounds.x, kTitleBarHeight + toolbarContainer_->bounds.h,
                     bounds_.width, kTitleBarHeight + toolbarContainer_->bounds.h, border);

    // Draw containers
    sidebarContainer_->paint(canvas);
    toolbarContainer_->paint(canvas);
    fileGridContainer_->paint(canvas);

    // Status bar
    SkPaint statusBg;
    statusBg.setColor(Color::fromHex(0xFFFFFF, 30).toSkia());
    canvas->drawRect(SkRect::MakeXYWH(statusContainer_->bounds.x, statusContainer_->bounds.y,
                                      statusContainer_->bounds.w, statusContainer_->bounds.h), statusBg);
    std::string status = std::to_string(filteredEntries_.size()) + " items";
    if (!currentPath_.empty()) status += "  |  " + currentPath_.string();
    drawText(canvas, status, statusContainer_->bounds.x + 12,
             statusContainer_->bounds.centerY() + 5, 12, Color::TextSecondary());

    // Context menu on top
    contextMenu_->paint(canvas);

    canvas->restore();
}

// =============================================================================
// Input Handling
// =============================================================================
bool FileManagerApp::onMouseMove(int x, int y) {
    mouseX_ = x; mouseY_ = y;
    if (contextMenu_->visible) {
        if (contextMenu_->onMouseMove(x, y)) requestRedraw();
        return true;
    }
    bool handled = false;
    if (sidebarContainer_->onMouseMove(x, y)) handled = true;
    if (toolbarContainer_->onMouseMove(x, y)) handled = true;
    if (fileGridContainer_->onMouseMove(x, y)) handled = true;
    return handled;
}

bool FileManagerApp::onMouseDown(int x, int y, int button) {
    if (contextMenu_->visible && !contextMenu_->hitTest(x, y)) {
        contextMenu_->hide();
        requestRedraw();
        return true;
    }
    if (contextMenu_->visible) {
        contextMenu_->onMouseUp(x, y, button);
        return true;
    }
    if (toolbarContainer_->onMouseDown(x, y, button)) { requestRedraw(); return true; }
    if (sidebarContainer_->onMouseDown(x, y, button)) { requestRedraw(); return true; }
    if (fileGridContainer_->onMouseDown(x, y, button)) { requestRedraw(); return true; }
    return false;
}

bool FileManagerApp::onMouseUp(int x, int y, int button) {
    if (contextMenu_->visible) {
        contextMenu_->onMouseUp(x, y, button);
        requestRedraw();
        return true;
    }
    bool handled = false;
    if (toolbarContainer_->onMouseUp(x, y, button)) handled = true;
    if (sidebarContainer_->onMouseUp(x, y, button)) handled = true;
    if (fileGridContainer_->onMouseUp(x, y, button)) handled = true;
    if (handled) requestRedraw();
    return handled;
}

bool FileManagerApp::onMouseScroll(int dx, int dy) {
    scrollOffsetY_ += dy * 30;
    scrollOffsetY_ = std::max(0.0f, std::min(scrollOffsetY_, maxScrollY_));
    // Apply scroll offset to file grid children
    for (auto& child : fileGridContainer_->children) {
        child->bounds.y -= dy * 30;
    }
    requestRedraw();
    return true;
}

} // namespace agro
