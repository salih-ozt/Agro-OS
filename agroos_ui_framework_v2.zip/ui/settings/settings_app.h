#pragma once

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <chrono>

#include "../common/agro_appwindow.h"
#include "../common/agro_widgets.h"
#include "../common/agro_layout.h"

namespace agro {

enum class SettingsView { Overview, Detail };

enum class SettingsCategory {
    System, Display, Personalization, Sound, Network, About
};

// =============================================================================
// SettingsApp: Wayland pencereli sistem ayarları
// =============================================================================
class SettingsApp : public AppWindow {
public:
    SettingsApp();
    ~SettingsApp() override = default;

    void onPaint(SkCanvas* canvas) override;
    bool onMouseMove(int x, int y) override;
    bool onMouseDown(int x, int y, int button) override;
    bool onMouseUp(int x, int y, int button) override;
    bool onMouseScroll(int dx, int dy) override;
    void onWindowResize(int width, int height) override;

private:
    void setupUI();
    void showOverview();
    void showCategory(SettingsCategory cat);
    void updateLayout();
    void loadSettings();
    void saveSettings();

    // Drawing sections
    void drawOverviewView(SkCanvas* canvas);
    void drawDetailView(SkCanvas* canvas);
    void drawSettingsCard(SkCanvas* canvas, const Rect& bounds, const std::string& title);

    // Category data
    struct CategoryInfo {
        std::string title;
        std::string description;
        std::string icon;
        Color accent;
    };
    std::map<SettingsCategory, CategoryInfo> categoryInfo_;

    // Settings data
    struct SettingsData {
        // Display
        int brightness = 80;
        int resolutionIndex = 2;
        std::vector<std::string> resolutions = {"1280x720", "1920x1080", "2560x1440", "3840x2160"};
        int scale = 100;

        // Personalization
        int wallpaperIndex = 0;
        std::vector<std::string> wallpapers = {"Default", "City", "Mountain", "Ocean", "Forest", "Abstract"};
        Color accentColor = Color::AccentBlue();
        bool darkMode = false;
        bool transparency = true;
        int themeIndex = 0;

        // Sound
        int volume = 60;
        bool mute = false;
        int inputVolume = 70;

        // Network
        bool wifiEnabled = true;
        bool bluetoothEnabled = false;
        bool airplaneMode = false;

        // System
        bool nightLight = false;
        bool notifications = true;
        std::string language = "English";
        std::vector<std::string> languages = {"English", "Turkish", "German", "French", "Spanish"};
    };
    SettingsData data_;

    // UI State
    SettingsView currentView_ = SettingsView::Overview;
    SettingsCategory currentCategory_ = SettingsCategory::System;
    float scrollOffsetY_ = 0;

    // Containers
    std::shared_ptr<UIContainer> overviewContainer_;
    std::shared_ptr<UIContainer> detailContainer_;
    std::shared_ptr<UIContainer> sidebarContainer_;
    std::shared_ptr<UIContainer> contentContainer_;
    std::shared_ptr<UIContainer> headerContainer_;
    std::shared_ptr<UITextInput> searchInput_;
    std::shared_ptr<UIButton> backButton_;

    // Overview widgets
    std::vector<std::shared_ptr<UICategoryCard>> categoryCards_;

    // Detail widgets (dynamic per category)
    std::vector<std::shared_ptr<UIWidget>> detailWidgets_;
    std::vector<std::shared_ptr<UISidebarItem>> sidebarItems_;
    std::vector<std::shared_ptr<UIWallpaperCard>> wallpaperCards_;

    // Layouts
    GridLayout overviewGrid_;
    SidebarLayout detailLayout_;

    // Animation
    float startupSlide_ = 0;
    float startupOpacity_ = 0;
    std::chrono::steady_clock::time_point startupTime_;
    std::chrono::steady_clock::time_point viewSwitchTime_;
};

} // namespace agro
