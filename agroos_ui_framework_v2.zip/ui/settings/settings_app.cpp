#include "settings_app.h"
#include <algorithm>
#include <fstream>

namespace agro {

// =============================================================================
// Constructor
// =============================================================================
SettingsApp::SettingsApp()
    : AppWindow("Settings", 1000, 700),
      startupTime_(std::chrono::steady_clock::now()),
      viewSwitchTime_(std::chrono::steady_clock::now()) {
    categoryInfo_ = {
        {SettingsCategory::System, {"System", "Display, sound, notifications, power", "💻", Color::fromHex(0x0078D4)}},
        {SettingsCategory::Display, {"Display", "Brightness, resolution, scaling", "🖥️", Color::fromHex(0x00B294)}},
        {SettingsCategory::Personalization, {"Personalization", "Background, colors, themes", "🎨", Color::fromHex(0x881798)}},
        {SettingsCategory::Sound, {"Sound", "Volume, input, output devices", "🔊", Color::fromHex(0xD83B01)}},
        {SettingsCategory::Network, {"Network", "Wi-Fi, Bluetooth, VPN", "📡", Color::fromHex(0x107C10)}},
        {SettingsCategory::About, {"About", "Device info, OS version", "ℹ️", Color::fromHex(0x5C2D91)}},
    };
    loadSettings();
    setupUI();
}

// =============================================================================
// Settings Persistence (JSON-like simple format)
// =============================================================================
void SettingsApp::loadSettings() {
    std::ifstream f(homeDir() + "/.config/agroos/settings.conf");
    if (!f) return;
    std::string key;
    while (f >> key) {
        if (key == "brightness") f >> data_.brightness;
        else if (key == "volume") f >> data_.volume;
        else if (key == "mute") f >> data_.mute;
        else if (key == "wifi") f >> data_.wifiEnabled;
        else if (key == "bluetooth") f >> data_.bluetoothEnabled;
        else if (key == "darkmode") f >> data_.darkMode;
        else if (key == "transparency") f >> data_.transparency;
        else if (key == "wallpaper") f >> data_.wallpaperIndex;
        else if (key == "language") f >> data_.language;
    }
}

void SettingsApp::saveSettings() {
    std::string path = homeDir() + "/.config/agroos";
    fs::create_directories(path);
    std::ofstream f(path + "/settings.conf");
    f << "brightness " << data_.brightness << "\n";
    f << "volume " << data_.volume << "\n";
    f << "mute " << data_.mute << "\n";
    f << "wifi " << data_.wifiEnabled << "\n";
    f << "bluetooth " << data_.bluetoothEnabled << "\n";
    f << "darkmode " << data_.darkMode << "\n";
    f << "transparency " << data_.transparency << "\n";
    f << "wallpaper " << data_.wallpaperIndex << "\n";
    f << "language " << data_.language << "\n";
}

// =============================================================================
// UI Setup
// =============================================================================
void SettingsApp::setupUI() {
    // Header
    headerContainer_ = std::make_shared<UIContainer>();
    headerContainer_->bounds = Rect(0, kTitleBarHeight, bounds_.width, 64);

    backButton_ = std::make_shared<UIButton>();
    backButton_->text = "◀ Back";
    backButton_->bounds = Rect(16, 16, 80, 32);
    backButton_->visible = false;
    backButton_->onClick = [this]() { showOverview(); };
    headerContainer_->addChild(backButton_);

    auto titleLabel = std::make_shared<UILabel>();
    titleLabel->text = "Settings";
    titleLabel->fontSize = 24;
    titleLabel->bold = true;
    titleLabel->bounds = Rect(16, 16, 200, 32);
    titleLabel->tag = "title";
    headerContainer_->addChild(titleLabel);

    searchInput_ = std::make_shared<UITextInput>();
    searchInput_->placeholder = "Find the setting";
    searchInput_->bounds = Rect(bounds_.width - 320, 14, 280, 36);
    headerContainer_->addChild(searchInput_);

    // Overview
    overviewContainer_ = std::make_shared<UIContainer>();
    overviewContainer_->bounds = Rect(0, kTitleBarHeight + 64, bounds_.width, bounds_.height - kTitleBarHeight - 64);

    for (const auto& [cat, info] : categoryInfo_) {
        auto card = std::make_shared<UICategoryCard>();
        card->title = info.title;
        card->description = info.description;
        card->iconUnicode = info.icon;
        card->accentColor = info.accent;
        card->bounds = Rect(0, 0, 160, 130);
        card->onClick = [this, cat]() { showCategory(cat); };
        categoryCards_.push_back(card);
        overviewContainer_->addChild(card);
    }

    overviewGrid_.columns = 3;
    overviewGrid_.itemWidth = 160;
    overviewGrid_.itemHeight = 130;
    overviewGrid_.gapX = 20;
    overviewGrid_.gapY = 20;
    overviewGrid_.padding = 24;

    // Detail view containers
    detailContainer_ = std::make_shared<UIContainer>();
    detailContainer_->visible = false;

    sidebarContainer_ = std::make_shared<UIContainer>();
    sidebarContainer_->bgColor = Color::AcrylicSidebar();
    detailContainer_->addChild(sidebarContainer_);

    contentContainer_ = std::make_shared<UIContainer>();
    detailContainer_->addChild(contentContainer_);

    for (const auto& [cat, info] : categoryInfo_) {
        auto item = std::make_shared<UISidebarItem>();
        item->iconUnicode = info.icon;
        item->label = info.title;
        item->iconColor = info.accent;
        item->bounds = Rect(0, 0, 200, 40);
        item->onClick = [this, cat]() { showCategory(cat); };
        sidebarItems_.push_back(item);
        sidebarContainer_->addChild(item);
    }
}

// =============================================================================
// View Switching
// =============================================================================
void SettingsApp::showOverview() {
    currentView_ = SettingsView::Overview;
    overviewContainer_->visible = true;
    detailContainer_->visible = false;
    backButton_->visible = false;
    for (auto& child : headerContainer_->children) {
        if (child->tag == "title") {
            std::static_pointer_cast<UILabel>(child)->text = "Settings";
        }
    }
    viewSwitchTime_ = std::chrono::steady_clock::now();
    updateLayout();
    requestRedraw();
}

void SettingsApp::showCategory(SettingsCategory cat) {
    currentCategory_ = cat;
    currentView_ = SettingsView::Detail;
    overviewContainer_->visible = false;
    detailContainer_->visible = true;
    backButton_->visible = true;

    for (auto& child : headerContainer_->children) {
        if (child->tag == "title") {
            std::static_pointer_cast<UILabel>(child)->text = categoryInfo_[cat].title;
        }
    }

    // Update sidebar selection
    for (auto& si : sidebarItems_) {
        si->isSelected = false;
    }
    size_t idx = static_cast<size_t>(cat);
    if (idx < sidebarItems_.size()) sidebarItems_[idx]->isSelected = true;

    // Build detail widgets
    contentContainer_->clearChildren();
    detailWidgets_.clear();
    wallpaperCards_.clear();
    scrollOffsetY_ = 0;

    float y = 16;
    float cardW = contentContainer_->bounds.w - 32;

    auto addCard = [&](const std::string& title) -> std::shared_ptr<UIContainer> {
        auto card = std::make_shared<UIContainer>();
        card->bgColor = Color::CardBg();
        card->cornerRadius = 12;
        card->bounds = Rect(16, y, cardW, 0); // height set later
        auto titleLbl = std::make_shared<UILabel>();
        titleLbl->text = title;
        titleLbl->fontSize = 16;
        titleLbl->bold = true;
        titleLbl->bounds = Rect(16, 12, 300, 24);
        card->addChild(titleLbl);
        contentContainer_->addChild(card);
        detailWidgets_.push_back(card);
        return card;
    };

    auto addToggle = [&](std::shared_ptr<UIContainer> card, const std::string& label,
                         bool& value, float& cy) {
        auto lbl = std::make_shared<UILabel>();
        lbl->text = label;
        lbl->fontSize = 14;
        lbl->bounds = Rect(16, cy + 8, 300, 20);
        card->addChild(lbl);

        auto sw = std::make_shared<UISwitch>();
        sw->checked = value;
        sw->bounds = Rect(card->bounds.w - 64, cy + 4, 48, 24);
        sw->onChange = [&value, this](bool v) { value = v; saveSettings(); };
        card->addChild(sw);
        cy += 40;
    };

    auto addSlider = [&](std::shared_ptr<UIContainer> card, const std::string& label,
                         int& value, float& cy, int minV = 0, int maxV = 100) {
        auto lbl = std::make_shared<UILabel>();
        lbl->text = label + "  " + std::to_string(value) + "%";
        lbl->fontSize = 14;
        lbl->bounds = Rect(16, cy + 4, 300, 20);
        card->addChild(lbl);

        auto slider = std::make_shared<UISlider>();
        slider->value = (value - minV) / float(maxV - minV);
        slider->bounds = Rect(16, cy + 28, card->bounds.w - 32, 24);
        slider->onChange = [&value, lbl, label, this](float v) {
            value = static_cast<int>(v * 100);
            lbl->text = label + "  " + std::to_string(value) + "%";
            saveSettings();
            requestRedraw();
        };
        card->addChild(slider);
        cy += 64;
    };

    auto addDropdown = [&](std::shared_ptr<UIContainer> card, const std::string& label,
                           std::vector<std::string>& options, int& selected, float& cy) {
        auto lbl = std::make_shared<UILabel>();
        lbl->text = label;
        lbl->fontSize = 14;
        lbl->bounds = Rect(16, cy + 4, 200, 20);
        card->addChild(lbl);

        auto dd = std::make_shared<UIDropdown>();
        dd->options = options;
        dd->selectedIndex = selected;
        dd->bounds = Rect(card->bounds.w - 220, cy, 200, 36);
        dd->onSelect = [&selected, this](int idx, const std::string&) {
            selected = idx; saveSettings(); requestRedraw();
        };
        card->addChild(dd);
        cy += 52;
    };

    switch (cat) {
        case SettingsCategory::System: {
            auto card = addCard("System Settings");
            float cy = 44;
            addToggle(card, "Night Light", data_.nightLight, cy);
            addToggle(card, "Notifications", data_.notifications, cy);
            addDropdown(card, "Language", data_.languages, reinterpret_cast<int&>(data_.language), cy);
            card->bounds.h = cy + 16;
            y += card->bounds.h + 16;
            break;
        }
        case SettingsCategory::Display: {
            auto card1 = addCard("Brightness & Color");
            float cy = 44;
            addSlider(card1, "Brightness", data_.brightness, cy);
            addToggle(card1, "Dark Mode", data_.darkMode, cy);
            addToggle(card1, "Transparency Effects", data_.transparency, cy);
            card1->bounds.h = cy + 16;
            y += card1->bounds.h + 16;

            auto card2 = addCard("Resolution & Scale");
            cy = 44;
            addDropdown(card2, "Display Resolution", data_.resolutions, data_.resolutionIndex, cy);
            addSlider(card2, "Scale", data_.scale, cy, 100, 200);
            card2->bounds.h = cy + 16;
            y += card2->bounds.h + 16;
            break;
        }
        case SettingsCategory::Personalization: {
            auto card = addCard("Background");
            float cy = 44;
            // Wallpaper grid
            auto wallLbl = std::make_shared<UILabel>();
            wallLbl->text = "Choose your background";
            wallLbl->fontSize = 14;
            wallLbl->bounds = Rect(16, cy, 300, 20);
            card->addChild(wallLbl);
            cy += 28;

            int col = 0;
            float wx = 16;
            for (size_t i = 0; i < data_.wallpapers.size(); ++i) {
                auto wc = std::make_shared<UIWallpaperCard>();
                wc->label = data_.wallpapers[i];
                wc->isSelected = (i == static_cast<size_t>(data_.wallpaperIndex));
                wc->bounds = Rect(wx, cy, 140, 90);
                wc->onClick = [this, i]() {
                    data_.wallpaperIndex = i;
                    for (auto& w : wallpaperCards_) w->isSelected = false;
                    wallpaperCards_[i]->isSelected = true;
                    saveSettings();
                    requestRedraw();
                };
                wallpaperCards_.push_back(wc);
                card->addChild(wc);
                col++;
                if (col >= 4) { col = 0; wx = 16; cy += 100; }
                else { wx += 152; }
            }
            if (col != 0) cy += 100;

            // Accent color picker (simplified)
            auto acLbl = std::make_shared<UILabel>();
            acLbl->text = "Accent Color";
            acLbl->fontSize = 14;
            acLbl->bounds = Rect(16, cy + 8, 200, 20);
            card->addChild(acLbl);
            cy += 40;

            card->bounds.h = cy + 16;
            y += card->bounds.h + 16;
            break;
        }
        case SettingsCategory::Sound: {
            auto card = addCard("Output");
            float cy = 44;
            addSlider(card, "Master Volume", data_.volume, cy);
            addToggle(card, "Mute", data_.mute, cy);
            card->bounds.h = cy + 16;
            y += card->bounds.h + 16;

            auto card2 = addCard("Input");
            cy = 44;
            addSlider(card2, "Input Volume", data_.inputVolume, cy);
            card2->bounds.h = cy + 16;
            y += card2->bounds.h + 16;
            break;
        }
        case SettingsCategory::Network: {
            auto card = addCard("Network & Internet");
            float cy = 44;
            addToggle(card, "Wi-Fi", data_.wifiEnabled, cy);
            addToggle(card, "Bluetooth", data_.bluetoothEnabled, cy);
            addToggle(card, "Airplane Mode", data_.airplaneMode, cy);
            card->bounds.h = cy + 16;
            y += card->bounds.h + 16;
            break;
        }
        case SettingsCategory::About: {
            auto card = addCard("Device Information");
            float cy = 44;
            struct InfoRow { const char* label; const char* value; };
            InfoRow rows[] = {
                {"OS Name", "AgroOS 1.0"},
                {"Version", "Build 2026.08.13"},
                {"Kernel", "Linux 6.10"},
                {"Desktop", "AgroUI (Wayland + Skia)"},
                {"Memory", "16 GB"},
                {"Storage", "512 GB NVMe"},
            };
            for (const auto& r : rows) {
                auto lbl = std::make_shared<UILabel>();
                lbl->text = r.label;
                lbl->fontSize = 14;
                lbl->color = Color::TextSecondary();
                lbl->bounds = Rect(16, cy, 200, 20);
                card->addChild(lbl);

                auto val = std::make_shared<UILabel>();
                val->text = r.value;
                val->fontSize = 14;
                val->bold = true;
                val->bounds = Rect(card->bounds.w - 300, cy, 280, 20);
                card->addChild(val);
                cy += 32;
            }
            card->bounds.h = cy + 16;
            y += card->bounds.h + 16;
            break;
        }
    }

    viewSwitchTime_ = std::chrono::steady_clock::now();
    updateLayout();
    requestRedraw();
}

// =============================================================================
// Layout
// =============================================================================
void SettingsApp::updateLayout() {
    float headerH = 64;
    float contentY = kTitleBarHeight + headerH;
    float contentH = bounds_.height - contentY;

    headerContainer_->bounds = Rect(0, kTitleBarHeight, bounds_.width, headerH);
    for (auto& child : headerContainer_->children) {
        if (child->tag == "title") {
            if (backButton_->visible) {
                child->bounds.x = 108;
            } else {
                child->bounds.x = 24;
            }
        }
    }
    backButton_->bounds = Rect(16, 16, 80, 32);
    searchInput_->bounds = Rect(bounds_.width - 320, 14, 280, 36);

    if (currentView_ == SettingsView::Overview) {
        overviewContainer_->bounds = Rect(0, contentY, bounds_.width, contentH);
        overviewGrid_.columns = std::max(1, (int)((bounds_.width - 48) / 180));
        overviewGrid_.apply(overviewContainer_->bounds, overviewContainer_->children);
    } else {
        detailContainer_->bounds = Rect(0, contentY, bounds_.width, contentH);
        detailLayout_.sidebarWidth = 220;
        detailLayout_.apply(detailContainer_->bounds, sidebarContainer_, contentContainer_);

        // Sidebar items
        float sy = 16;
        for (auto& si : sidebarItems_) {
            si->bounds = Rect(8, sy, detailLayout_.sidebarWidth - 16, 40);
            sy += 44;
        }

        // Content scroll
        for (auto& w : contentContainer_->children) {
            w->bounds.w = contentContainer_->bounds.w - 32;
        }
    }
}

void SettingsApp::onWindowResize(int width, int height) {
    AppWindow::onWindowResize(width, height);
    updateLayout();
}

// =============================================================================
// Drawing
// =============================================================================
void SettingsApp::onPaint(SkCanvas* canvas) {
    auto now = std::chrono::steady_clock::now();
    float ms = std::chrono::duration<float, std::milli>(now - startupTime_).count();
    float t = std::min(1.0f, ms / 500.0f);
    startupOpacity_ = easeOutCubic(t);
    startupSlide_ = (1.0f - easeOutCubic(t)) * 20.0f;

    // View switch animation
    float vms = std::chrono::duration<float, std::milli>(now - viewSwitchTime_).count();
    float viewT = std::min(1.0f, vms / 300.0f);
    float viewSlide = (1.0f - easeOutCubic(viewT)) * 15.0f;
    float viewAlpha = easeOutCubic(viewT);

    canvas->save();
    canvas->translate(0, startupSlide_);

    // Header background
    SkPaint headerBg;
    headerBg.setColor(Color::fromHex(0xFFFFFF, 30).toSkia());
    canvas->drawRect(SkRect::MakeXYWH(0, kTitleBarHeight, bounds_.width, 64), headerBg);

    SkPaint border;
    border.setColor(Color::Border().toSkia());
    border.setStrokeWidth(1);
    canvas->drawLine(0, kTitleBarHeight + 64, bounds_.width, kTitleBarHeight + 64, border);

    headerContainer_->paint(canvas);

    canvas->save();
    canvas->translate(0, viewSlide);

    if (currentView_ == SettingsView::Overview) {
        overviewContainer_->paint(canvas);
    } else {
        // Sidebar bg
        SkPaint sbBg;
        sbBg.setColor(Color::AcrylicSidebar().toSkia());
        canvas->drawRect(SkRect::MakeXYWH(0, kTitleBarHeight + 64,
                                          sidebarContainer_->bounds.w, bounds_.height - kTitleBarHeight - 64), sbBg);
        canvas->drawLine(sidebarContainer_->bounds.right(), kTitleBarHeight + 64,
                         sidebarContainer_->bounds.right(), bounds_.height, border);
        sidebarContainer_->paint(canvas);
        contentContainer_->paint(canvas);
    }

    canvas->restore();
    canvas->restore();
}

// =============================================================================
// Input Handling
// =============================================================================
bool SettingsApp::onMouseMove(int x, int y) {
    if (headerContainer_->onMouseMove(x, y)) { requestRedraw(); return true; }
    if (currentView_ == SettingsView::Overview) {
        if (overviewContainer_->onMouseMove(x, y)) { requestRedraw(); return true; }
    } else {
        if (sidebarContainer_->onMouseMove(x, y)) { requestRedraw(); return true; }
        if (contentContainer_->onMouseMove(x, y)) { requestRedraw(); return true; }
    }
    return false;
}

bool SettingsApp::onMouseDown(int x, int y, int button) {
    if (headerContainer_->onMouseDown(x, y, button)) { requestRedraw(); return true; }
    if (currentView_ == SettingsView::Overview) {
        if (overviewContainer_->onMouseDown(x, y, button)) { requestRedraw(); return true; }
    } else {
        if (sidebarContainer_->onMouseDown(x, y, button)) { requestRedraw(); return true; }
        if (contentContainer_->onMouseDown(x, y, button)) { requestRedraw(); return true; }
    }
    return false;
}

bool SettingsApp::onMouseUp(int x, int y, int button) {
    if (headerContainer_->onMouseUp(x, y, button)) { requestRedraw(); return true; }
    if (currentView_ == SettingsView::Overview) {
        if (overviewContainer_->onMouseUp(x, y, button)) { requestRedraw(); return true; }
    } else {
        if (sidebarContainer_->onMouseUp(x, y, button)) { requestRedraw(); return true; }
        if (contentContainer_->onMouseUp(x, y, button)) { requestRedraw(); return true; }
    }
    return false;
}

bool SettingsApp::onMouseScroll(int dx, int dy) {
    if (currentView_ == SettingsView::Detail) {
        scrollOffsetY_ += dy * 30;
        scrollOffsetY_ = std::max(0.0f, scrollOffsetY_);
        for (auto& child : contentContainer_->children) {
            child->bounds.y -= dy * 30;
        }
        requestRedraw();
        return true;
    }
    return false;
}

} // namespace agro
