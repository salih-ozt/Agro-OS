#pragma once

#include <wayland-client.h>
#include <xdg-shell-client-protocol.h>
#include <string>
#include <memory>
#include <functional>
#include <vector>
#include <chrono>
#include <cstring>

#include "include/core/SkCanvas.h"
#include "include/core/SkSurface.h"
#include "include/core/SkBitmap.h"
#include "include/core/SkRRect.h"
#include "include/core/SkPaint.h"
#include "include/core/SkColor.h"
#include "include/core/SkFont.h"
#include "include/core/SkTextBlob.h"
#include "include/effects/SkImageFilters.h"
#include "include/effects/SkBlurMaskFilter.h"

#include "agro_math.h"

namespace agro {

enum class WindowState { Normal, Maximized, Minimized, Fullscreen };

struct AppWindowBounds {
    int x = 0, y = 0, width = 1024, height = 768;
};

// =============================================================================
// AppWindow: Tüm uygulamaların türediği Wayland pencere taban sınıfı
// =============================================================================
class AppWindow {
public:
    AppWindow(const std::string& title, int width, int height);
    virtual ~AppWindow();

    // Lifecycle
    bool initialize();
    void runEventLoop();
    void shutdown();
    void requestClose();

    // Rendering
    void requestRedraw();
    bool needsRedraw() const { return needsRedraw_; }

    // Derived classes implement this
    virtual void onPaint(SkCanvas* canvas) = 0;

    // Input events (return true if handled)
    virtual bool onMouseMove(int x, int y) { return false; }
    virtual bool onMouseDown(int x, int y, int button) { return false; }
    virtual bool onMouseUp(int x, int y, int button) { return false; }
    virtual bool onMouseScroll(int dx, int dy) { return false; }
    virtual bool onKey(uint32_t key, bool pressed) { return false; }
    virtual void onWindowResize(int width, int height);

    // Getters
    int width() const { return bounds_.width; }
    int height() const { return bounds_.height; }
    WindowState state() const { return state_; }
    bool isActive() const { return isActive_; }
    const std::string& title() const { return title_; }

    // Animation helpers
    float startupAnimation() const;
    float easeOutCubic(float t) const;

protected:
    // Chrome drawing (Titlebar, buttons, shadow, acrylic)
    void drawWindowChrome(SkCanvas* canvas);
    void drawAcrylicBackground(SkCanvas* canvas);
    void drawDropShadow(SkCanvas* canvas);
    void drawTitleBar(SkCanvas* canvas);
    void drawTitleTab(SkCanvas* canvas);
    void drawWindowControls(SkCanvas* canvas);

    // Hit testing
    bool hitTestTitleBar(int x, int y) const;
    bool hitTestClose(int x, int y) const;
    bool hitTestMaximize(int x, int y) const;
    bool hitTestMinimize(int x, int y) const;

    // Wayland static callbacks
    static void registryGlobalCb(void* data, wl_registry* registry, uint32_t id,
                                 const char* interface, uint32_t version);
    static void registryGlobalRemoveCb(void* data, wl_registry* registry, uint32_t id);
    static void xdgWmBasePingCb(void* data, xdg_wm_base* xdg_wm_base, uint32_t serial);
    static void xdgSurfaceConfigureCb(void* data, xdg_surface* xdg_surface, uint32_t serial);
    static void xdgToplevelConfigureCb(void* data, xdg_toplevel* toplevel,
                                       int32_t width, int32_t height, wl_array* states);
    static void xdgToplevelCloseCb(void* data, xdg_toplevel* toplevel);
    static void seatCapabilitiesCb(void* data, wl_seat* seat, uint32_t caps);
    static void seatNameCb(void* data, wl_seat* seat, const char* name);
    static void pointerEnterCb(void* data, wl_pointer* pointer, uint32_t serial,
                               wl_surface* surface, wl_fixed_t sx, wl_fixed_t sy);
    static void pointerLeaveCb(void* data, wl_pointer* pointer, uint32_t serial,
                               wl_surface* surface);
    static void pointerMotionCb(void* data, wl_pointer* pointer, uint32_t time,
                                wl_fixed_t sx, wl_fixed_t sy);
    static void pointerButtonCb(void* data, wl_pointer* pointer, uint32_t serial,
                                uint32_t time, uint32_t button, uint32_t state);
    static void pointerAxisCb(void* data, wl_pointer* pointer, uint32_t time,
                              uint32_t axis, wl_fixed_t value);
    static void pointerFrameCb(void* data, wl_pointer* pointer);
    static void pointerAxisSourceCb(void* data, wl_pointer* pointer, uint32_t axis_source);
    static void pointerAxisStopCb(void* data, wl_pointer* pointer, uint32_t time, uint32_t axis);
    static void pointerAxisDiscreteCb(void* data, wl_pointer* pointer, uint32_t axis, int32_t discrete);
    static void bufferReleaseCb(void* data, wl_buffer* buffer);

    // Buffer management
    bool createShmBuffer(int width, int height);
    void destroyShmBuffer();
    int createAnonymousFile(size_t size);
    void commitSurface();

    // State
    std::string title_;
    AppWindowBounds bounds_;
    AppWindowBounds pendingBounds_;
    WindowState state_ = WindowState::Normal;
    bool running_ = false;
    bool needsRedraw_ = true;
    bool isActive_ = true;
    bool isClosed_ = false;

    // Wayland objects
    wl_display* display_ = nullptr;
    wl_registry* registry_ = nullptr;
    wl_compositor* compositor_ = nullptr;
    wl_shm* shm_ = nullptr;
    wl_seat* seat_ = nullptr;
    wl_pointer* pointer_ = nullptr;
    wl_surface* surface_ = nullptr;
    xdg_wm_base* xdgWmBase_ = nullptr;
    xdg_surface* xdgSurface_ = nullptr;
    xdg_toplevel* xdgToplevel_ = nullptr;

    // Buffer
    wl_buffer* buffer_ = nullptr;
    SkBitmap bitmap_;
    sk_sp<SkSurface> skSurface_;
    void* shmData_ = nullptr;
    size_t shmSize_ = 0;
    int shmFd_ = -1;

    // Input state
    int mouseX_ = 0, mouseY_ = 0;
    bool mousePressed_ = false;
    bool mouseInClose_ = false;
    bool mouseInMaximize_ = false;
    bool mouseInMinimize_ = false;
    bool draggingWindow_ = false;
    int dragStartX_ = 0, dragStartY_ = 0;
    int windowStartX_ = 0, windowStartY_ = 0;

    // Animation
    std::chrono::steady_clock::time_point startupTime_;

    // Title bar metrics
    static constexpr int kTitleBarHeight = 44;
    static constexpr int kWindowRadius = 12;
    static constexpr int kButtonSize = 14;
    static constexpr int kButtonGap = 16;
    static constexpr int kTabWidth = 160;
    static constexpr int kTabHeight = 32;
};

} // namespace agro
