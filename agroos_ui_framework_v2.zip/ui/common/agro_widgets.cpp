#include "agro_widgets.h"
#include <cmath>
#include <algorithm>

namespace agro {

// =============================================================================
// Helper: Draw rounded rect with optional fill/stroke
// =============================================================================
static void drawRR(SkCanvas* c, const Rect& r, float radius, const SkPaint& paint) {
    SkRRect rr = SkRRect::MakeRectXY(SkRect::MakeXYWH(r.x, r.y, r.w, r.h), radius, radius);
    c->drawRRect(rr, paint);
}

static SkPaint fillPaint(const Color& col) {
    SkPaint p; p.setAntiAlias(true); p.setColor(col.toSkia()); return p;
}

static SkPaint strokePaint(const Color& col, float width = 1.0f) {
    SkPaint p; p.setAntiAlias(true); p.setStyle(SkPaint::kStroke_Style);
    p.setStrokeWidth(width); p.setColor(col.toSkia()); return p;
}

static void drawText(SkCanvas* c, const std::string& text, float x, float y,
                     float size, const Color& col, bool bold = false) {
    SkFont font(nullptr, size);
    font.setSubpixel(true);
    font.setEmbolden(bold);
    SkPaint paint;
    paint.setColor(col.toSkia());
    paint.setAntiAlias(true);
    auto blob = SkTextBlob::MakeFromString(text.c_str(), font);
    c->drawTextBlob(blob.get(), x, y, paint);
}

static float measureText(const std::string& text, float size) {
    SkFont font(nullptr, size);
    font.setSubpixel(true);
    SkRect bounds;
    font.measureText(text.c_str(), text.length(), SkTextEncoding::kUTF8, &bounds);
    return bounds.width();
}

static std::string truncateText(const std::string& text, float maxWidth, float fontSize) {
    if (measureText(text, fontSize) <= maxWidth) return text;
    std::string result = text;
    while (!result.empty() && measureText(result + "…", fontSize) > maxWidth) {
        result.pop_back();
    }
    return result + "…";
}

// =============================================================================
// UILabel
// =============================================================================
void UILabel::paint(SkCanvas* canvas) {
    if (!visible || text.empty()) return;
    drawText(canvas, text, bounds.x, bounds.y + fontSize * 0.8f, fontSize, color, bold);
}

float UILabel::measuredWidth() const {
    return measureText(text, fontSize);
}

// =============================================================================
// UIButton
// =============================================================================
void UIButton::paint(SkCanvas* canvas) {
    if (!visible) return;
    SkPaint bg = fillPaint(pressed ? activeColor : (hovered ? hoverColor : bgColor));
    drawRR(canvas, bounds, cornerRadius, bg);

    if (!icon.empty()) {
        drawText(canvas, icon, bounds.x + 10, bounds.centerY() + fontSize * 0.35f, fontSize + 2, textColor);
        drawText(canvas, text, bounds.x + 32, bounds.centerY() + fontSize * 0.35f, fontSize, textColor);
    } else {
        float tw = measureText(text, fontSize);
        drawText(canvas, text, bounds.centerX() - tw / 2, bounds.centerY() + fontSize * 0.35f, fontSize, textColor);
    }
}

bool UIButton::onMouseMove(float x, float y) {
    bool old = hovered;
    hovered = hitTest(x, y);
    return old != hovered;
}

bool UIButton::onMouseDown(float x, float y, int button) {
    if (hitTest(x, y) && button == 0) {
        pressed = true;
        return true;
    }
    return false;
}

bool UIButton::onMouseUp(float x, float y, int button) {
    if (pressed && button == 0) {
        pressed = false;
        if (hitTest(x, y) && onClick) onClick();
        return true;
    }
    pressed = false;
    return false;
}

// =============================================================================
// UIIconButton
// =============================================================================
void UIIconButton::paint(SkCanvas* canvas) {
    if (!visible) return;
    if (hovered || pressed) {
        SkPaint bg = fillPaint(pressed ? activeBg : hoverBg);
        drawRR(canvas, bounds, cornerRadius, bg);
    }
    drawText(canvas, icon, bounds.centerX() - iconSize * 0.35f,
             bounds.centerY() + iconSize * 0.35f, iconSize, iconColor);
}

bool UIIconButton::onMouseMove(float x, float y) {
    bool old = hovered; hovered = hitTest(x, y); return old != hovered;
}
bool UIIconButton::onMouseDown(float x, float y, int button) {
    if (hitTest(x, y) && button == 0) { pressed = true; return true; }
    return false;
}
bool UIIconButton::onMouseUp(float x, float y, int button) {
    if (pressed && button == 0) {
        pressed = false;
        if (hitTest(x, y) && onClick) onClick();
        return true;
    }
    pressed = false; return false;
}

// =============================================================================
// UITextInput
// =============================================================================
void UITextInput::paint(SkCanvas* canvas) {
    if (!visible) return;

    // Background
    SkPaint bg = fillPaint(focused ? bgColor.lighten(0.1f) : bgColor);
    drawRR(canvas, bounds, cornerRadius, bg);

    // Border
    SkPaint border = strokePaint(focused ? Color::AccentBlue() : borderColor, focused ? 2.0f : 1.0f);
    drawRR(canvas, bounds, cornerRadius, border);

    // Search icon
    drawText(canvas, "🔍", bounds.x + 10, bounds.centerY() + 5, 14, Color::TextTertiary());

    float textX = bounds.x + 32;
    float textY = bounds.centerY() + fontSize * 0.35f;

    if (text.empty() && !focused) {
        drawText(canvas, placeholder, textX, textY, fontSize, placeholderColor);
    } else {
        drawText(canvas, text, textX - scrollOffset_, textY, fontSize, textColor);
    }

    // Cursor
    if (focused) {
        auto now = std::chrono::steady_clock::now();
        float ms = std::chrono::duration<float, std::milli>(now - focusTime_).count();
        if (static_cast<int>(ms / 530) % 2 == 0) {
            float cx = textX - scrollOffset_;
            for (size_t i = 0; i < cursorPos_ && i < text.size(); ) {
                int len = 1;
                if ((text[i] & 0x80) != 0) {
                    if ((text[i] & 0xE0) == 0xC0) len = 2;
                    else if ((text[i] & 0xF0) == 0xE0) len = 3;
                    else if ((text[i] & 0xF8) == 0xF0) len = 4;
                }
                cx += measureText(text.substr(i, len), fontSize);
                i += len;
            }
            SkPaint cursorPaint;
            cursorPaint.setColor(Color::AccentBlue().toSkia());
            cursorPaint.setStrokeWidth(1.5f);
            canvas->drawLine(cx, bounds.y + 6, cx, bounds.bottom() - 6, cursorPaint);
        }
    }
}

bool UITextInput::onMouseDown(float x, float y, int button) {
    if (hitTest(x, y)) { focused = true; focusTime_ = std::chrono::steady_clock::now(); return true; }
    focused = false; return false;
}

bool UITextInput::onKey(uint32_t key, bool pressed) {
    if (!focused || !pressed) return false;
    if (key == 65288) { // Backspace
        deleteBackward(); return true;
    }
    if (key == 65307) { // Escape
        focused = false; return true;
    }
    if (key == 65293) { // Enter
        if (onSubmit) onSubmit();
        return true;
    }
    return false;
}

bool UITextInput::onTextInput(const std::string& t) {
    if (!focused) return false;
    insertText(t);
    return true;
}

void UITextInput::insertText(const std::string& t) {
    if (text.length() + t.length() > static_cast<size_t>(maxLength)) return;
    text.insert(cursorPos_, t);
    cursorPos_ += t.length();
    if (onChange) onChange(text);
}

void UITextInput::deleteBackward() {
    if (cursorPos_ > 0 && !text.empty()) {
        size_t start = cursorPos_ - 1;
        while (start > 0 && (text[start] & 0xC0) == 0x80) start--;
        text.erase(start, cursorPos_ - start);
        cursorPos_ = start;
        if (onChange) onChange(text);
    }
}

// =============================================================================
// UISwitch
// =============================================================================
float UISwitch::getAnimatedProgress() const {
    auto now = std::chrono::steady_clock::now();
    float ms = std::chrono::duration<float, std::milli>(now - toggleTime_).count();
    float target = checked ? 1.0f : 0.0f;
    if (ms > 200) return target;
    float start = checked ? 0.0f : 1.0f;
    float t = ms / 200.0f;
    t = 1.0f - std::pow(1.0f - t, 3); // easeOutCubic
    return start + (target - start) * t;
}

void UISwitch::paint(SkCanvas* canvas) {
    if (!visible) return;
    float prog = getAnimatedProgress();
    float h = bounds.h;
    float w = bounds.w;
    float r = h / 2;

    // Track
    SkPaint trackPaint;
    trackPaint.setAntiAlias(true);
    Color trackCol = Color::lerp(trackOff, trackOn, prog);
    trackPaint.setColor(trackCol.toSkia());
    canvas->drawRoundRect(SkRect::MakeXYWH(bounds.x, bounds.y, w, h), r, r, trackPaint);

    // Thumb
    float thumbR = r - 3;
    float thumbX = bounds.x + r + (w - 2 * r) * prog;
    float thumbY = bounds.y + h / 2;
    SkPaint thumbPaint;
    thumbPaint.setAntiAlias(true);
    thumbPaint.setColor(thumbColor.toSkia());
    thumbPaint.setShadowLayer(2, 0, 1, SkColorSetARGB(60, 0, 0, 0));
    canvas->drawCircle(thumbX, thumbY, thumbR, thumbPaint);
}

bool UISwitch::onMouseUp(float x, float y, int button) {
    if (hitTest(x, y) && button == 0) {
        checked = !checked;
        toggleTime_ = std::chrono::steady_clock::now();
        if (onChange) onChange(checked);
        return true;
    }
    return false;
}

bool UISwitch::onMouseMove(float x, float y) {
    bool old = hovered; hovered = hitTest(x, y); return old != hovered;
}

// =============================================================================
// UISlider
// =============================================================================
float UISlider::valueFromPos(float x) const {
    float t = (x - bounds.x) / bounds.w;
    t = std::max(0.0f, std::min(1.0f, t));
    return minValue + t * (maxValue - minValue);
}

void UISlider::paint(SkCanvas* canvas) {
    if (!visible) return;
    float cy = bounds.centerY();
    float halfTrack = trackHeight / 2;
    float t = (value - minValue) / (maxValue - minValue);
    float fillW = bounds.w * t;

    // Track background
    SkPaint trackPaint;
    trackPaint.setAntiAlias(true);
    trackPaint.setColor(trackColor.toSkia());
    canvas->drawRoundRect(SkRect::MakeXYWH(bounds.x, cy - halfTrack, bounds.w, trackHeight),
                          halfTrack, halfTrack, trackPaint);

    // Fill
    SkPaint fillPaint;
    fillPaint.setAntiAlias(true);
    fillPaint.setColor(fillColor.toSkia());
    canvas->drawRoundRect(SkRect::MakeXYWH(bounds.x, cy - halfTrack, fillW, trackHeight),
                          halfTrack, halfTrack, fillPaint);

    // Thumb
    float thumbX = bounds.x + fillW;
    SkPaint thumbPaint;
    thumbPaint.setAntiAlias(true);
    thumbPaint.setColor(thumbColor.toSkia());
    thumbPaint.setShadowLayer(3, 0, 1, SkColorSetARGB(80, 0, 0, 0));
    canvas->drawCircle(thumbX, cy, thumbRadius, thumbPaint);
}

bool UISlider::onMouseDown(float x, float y, int button) {
    if (hitTest(x, y) && button == 0) {
        dragging_ = true;
        value = valueFromPos(x);
        if (onChange) onChange(value);
        return true;
    }
    return false;
}

bool UISlider::onMouseMove(float x, float y) {
    if (dragging_) {
        value = valueFromPos(x);
        if (onChange) onChange(value);
        return true;
    }
    return false;
}

bool UISlider::onMouseUp(float x, float y, int button) {
    if (dragging_ && button == 0) {
        dragging_ = false;
        return true;
    }
    return false;
}

// =============================================================================
// UIDropdown
// =============================================================================
void UIDropdown::paint(SkCanvas* canvas) {
    if (!visible) return;
    // Main box
    SkPaint bg = fillPaint(bgColor);
    drawRR(canvas, bounds, cornerRadius, bg);
    SkPaint border = strokePaint(Color::Border());
    drawRR(canvas, bounds, cornerRadius, border);

    std::string display = (selectedIndex >= 0 && selectedIndex < (int)options.size())
                          ? options[selectedIndex] : placeholder;
    drawText(canvas, display, bounds.x + 12, bounds.centerY() + fontSize * 0.35f, fontSize, textColor);

    // Arrow
    float ax = bounds.right() - 20;
    float ay = bounds.centerY();
    SkPaint arrow;
    arrow.setAntiAlias(true);
    arrow.setColor(Color::TextSecondary().toSkia());
    arrow.setStrokeWidth(1.5f);
    if (expanded_) {
        canvas->drawLine(ax - 4, ay + 2, ax, ay - 3, arrow);
        canvas->drawLine(ax, ay - 3, ax + 4, ay + 2, arrow);
    } else {
        canvas->drawLine(ax - 4, ay - 2, ax, ay + 3, arrow);
        canvas->drawLine(ax, ay + 3, ax + 4, ay - 2, arrow);
    }

    // Expanded list
    if (expanded_) {
        float itemH = 32;
        float listY = bounds.bottom() + 4;
        float listH = options.size() * itemH + 8;
        SkPaint listBg = fillPaint(Color::fromHex(0xFFFFFF, 245));
        SkRRect listRR = SkRRect::MakeRectXY(SkRect::MakeXYWH(bounds.x, listY, bounds.w, listH), 8, 8);
        canvas->drawRRect(listRR, listBg);
        canvas->drawRRect(listRR, strokePaint(Color::Border()));

        for (size_t i = 0; i < options.size(); ++i) {
            float iy = listY + 4 + i * itemH;
            if ((int)i == hoverIndex_) {
                SkPaint hi = fillPaint(Color::HoverBg());
                canvas->drawRRect(SkRRect::MakeRectXY(
                    SkRect::MakeXYWH(bounds.x + 4, iy, bounds.w - 8, itemH), 4, 4), hi);
            }
            drawText(canvas, options[i], bounds.x + 16, iy + itemH * 0.65f, fontSize,
                     (int)i == selectedIndex ? Color::AccentBlue() : Color::TextPrimary());
        }
    }
}

bool UIDropdown::onMouseUp(float x, float y, int button) {
    if (!visible) return false;
    if (button != 0) return false;

    if (expanded_) {
        float itemH = 32;
        float listY = bounds.bottom() + 4;
        for (size_t i = 0; i < options.size(); ++i) {
            float iy = listY + 4 + i * itemH;
            if (y >= iy && y <= iy + itemH) {
                selectedIndex = i;
                if (onSelect) onSelect(i, options[i]);
                expanded_ = false;
                return true;
            }
        }
        expanded_ = false;
        return true;
    }

    if (hitTest(x, y)) {
        expanded_ = true;
        return true;
    }
    return false;
}

bool UIDropdown::onMouseMove(float x, float y) {
    if (!expanded_) return false;
    float itemH = 32;
    float listY = bounds.bottom() + 4;
    int old = hoverIndex_;
    hoverIndex_ = -1;
    for (size_t i = 0; i < options.size(); ++i) {
        float iy = listY + 4 + i * itemH;
        if (y >= iy && y <= iy + itemH) {
            hoverIndex_ = i; break;
        }
    }
    return old != hoverIndex_;
}

void UIDropdown::closeDropdown() {
    expanded_ = false;
}

// =============================================================================
// UIContextMenu
// =============================================================================
void UIContextMenu::updateBounds() {
    float maxW = 120;
    for (const auto& it : items) {
        float w = measureText(it.label, fontSize) + 40;
        if (!it.shortcut.empty()) w += measureText(it.shortcut, fontSize) + 20;
        maxW = std::max(maxW, w);
    }
    bounds.w = maxW;
    bounds.h = items.size() * itemHeight + 8;
}

void UIContextMenu::show(float x, float y) {
    updateBounds();
    bounds.x = x;
    bounds.y = y;
    visible = true;
    hoverIndex_ = -1;
}

void UIContextMenu::hide() {
    visible = false;
    hoverIndex_ = -1;
}

void UIContextMenu::paint(SkCanvas* canvas) {
    if (!visible) return;
    SkPaint bg = fillPaint(bgColor);
    SkRRect rr = SkRRect::MakeRectXY(SkRect::MakeXYWH(bounds.x, bounds.y, bounds.w, bounds.h), cornerRadius, cornerRadius);
    canvas->drawRRect(rr, bg);
    canvas->drawRRect(rr, strokePaint(Color::Border()));

    // Shadow
    SkPaint shadow;
    shadow.setAntiAlias(true);
    shadow.setColor(SkColorSetARGB(40, 0, 0, 0));
    shadow.setMaskFilter(SkMaskFilter::MakeBlur(kNormal_SkBlurStyle, 12));
    canvas->drawRRect(rr, shadow);

    float iy = bounds.y + 4;
    for (size_t i = 0; i < items.size(); ++i) {
        const auto& it = items[i];
        if (it.separator) {
            SkPaint sep;
            sep.setColor(Color::Border().toSkia());
            sep.setStrokeWidth(1);
            canvas->drawLine(bounds.x + 8, iy + itemHeight / 2,
                             bounds.right() - 8, iy + itemHeight / 2, sep);
        } else {
            if ((int)i == hoverIndex_ && it.enabled) {
                SkPaint hi = fillPaint(hoverColor);
                canvas->drawRRect(SkRRect::MakeRectXY(
                    SkRect::MakeXYWH(bounds.x + 4, iy, bounds.w - 8, itemHeight), 4, 4), hi);
            }
            Color col = it.enabled ? textColor : Color::TextTertiary();
            drawText(canvas, it.label, bounds.x + 16, iy + itemHeight * 0.65f, fontSize, col);
            if (!it.shortcut.empty()) {
                drawText(canvas, it.shortcut, bounds.right() - 16 - measureText(it.shortcut, fontSize),
                         iy + itemHeight * 0.65f, fontSize, shortcutColor);
            }
        }
        iy += itemHeight;
    }
}

bool UIContextMenu::onMouseMove(float x, float y) {
    if (!visible) return false;
    int old = hoverIndex_;
    hoverIndex_ = -1;
    float iy = bounds.y + 4;
    for (size_t i = 0; i < items.size(); ++i) {
        if (x >= bounds.x && x <= bounds.right() && y >= iy && y <= iy + itemHeight) {
            hoverIndex_ = i; break;
        }
        iy += itemHeight;
    }
    return old != hoverIndex_;
}

bool UIContextMenu::onMouseUp(float x, float y, int button) {
    if (!visible || button != 0) return false;
    if (hoverIndex_ >= 0 && hoverIndex_ < (int)items.size()) {
        const auto& it = items[hoverIndex_];
        if (it.enabled && it.action) it.action();
    }
    hide();
    return true;
}

// =============================================================================
// UIFileItem
// =============================================================================
void UIFileItem::drawFolderIcon(SkCanvas* canvas, float cx, float cy, float size) {
    float w = size;
    float h = size * 0.75f;
    float x = cx - w / 2;
    float y = cy - h / 2;
    float tabH = h * 0.18f;
    float tabW = w * 0.35f;

    // Back tab
    SkPaint tabPaint;
    tabPaint.setAntiAlias(true);
    tabPaint.setColor(folderDark.toSkia());
    SkPath tabPath;
    tabPath.moveTo(x + 4, y);
    tabPath.lineTo(x + tabW, y);
    tabPath.lineTo(x + tabW - 4, y + tabH);
    tabPath.lineTo(x, y + tabH);
    tabPath.close();
    canvas->drawPath(tabPath, tabPaint);

    // Main body
    SkPaint bodyPaint;
    bodyPaint.setAntiAlias(true);
    bodyPaint.setColor(folderColor.toSkia());
    SkRRect body = SkRRect::MakeRectXY(SkRect::MakeXYWH(x, y + tabH - 2, w, h - tabH + 2), 6, 6);
    canvas->drawRRect(body, bodyPaint);

    // Highlight
    SkPaint hi;
    hi.setAntiAlias(true);
    hi.setColor(SkColorSetARGB(40, 255, 255, 255));
    canvas->drawRRect(body, hi);
}

void UIFileItem::drawFileIcon(SkCanvas* canvas, float cx, float cy, float size) {
    float w = size * 0.65f;
    float h = size * 0.8f;
    float x = cx - w / 2;
    float y = cy - h / 2;

    SkPaint paper;
    paper.setAntiAlias(true);
    paper.setColor(Color::fromHex(0xFFFFFF).toSkia());
    SkRRect rr = SkRRect::MakeRectXY(SkRect::MakeXYWH(x, y, w, h), 4, 4);
    canvas->drawRRect(rr, paper);
    canvas->drawRRect(rr, strokePaint(Color::Border()));

    // Folded corner
    SkPath fold;
    fold.moveTo(x + w - 12, y);
    fold.lineTo(x + w, y + 12);
    fold.lineTo(x + w, y);
    fold.close();
    SkPaint foldPaint;
    foldPaint.setAntiAlias(true);
    foldPaint.setColor(Color::fromHex(0xE0E0E0).toSkia());
    canvas->drawPath(fold, foldPaint);

    // Lines
    SkPaint line;
    line.setColor(Color::TrackBg().toSkia());
    line.setStrokeWidth(2);
    for (int i = 0; i < 3; ++i) {
        canvas->drawLine(x + 6, y + 20 + i * 7, x + w - 6, y + 20 + i * 7, line);
    }
}

void UIFileItem::paint(SkCanvas* canvas) {
    if (!visible) return;

    // Selection background
    if (isSelected) {
        SkPaint sel;
        sel.setAntiAlias(true);
        sel.setColor(Color::ActiveBg().toSkia());
        drawRR(canvas, bounds, cornerRadius, sel);
        // Border
        SkPaint selBorder = strokePaint(Color::AccentBlue(), 1.5f);
        drawRR(canvas, bounds, cornerRadius, selBorder);
    } else if (hovered) {
        SkPaint hov;
        hov.setAntiAlias(true);
        hov.setColor(Color::HoverBg().toSkia());
        drawRR(canvas, bounds, cornerRadius, hov);
    }

    float cx = bounds.centerX();
    float iconY = bounds.y + iconSize / 2 + 8;

    if (isDirectory) {
        drawFolderIcon(canvas, cx, iconY, iconSize);
    } else {
        drawFileIcon(canvas, cx, iconY, iconSize);
    }

    // Filename (max 2 lines, ellipsis)
    float textY = iconY + iconSize / 2 + 16;
    float maxW = bounds.w - 8;
    std::string line1 = truncateText(filename, maxW, 12);
    drawText(canvas, line1, bounds.x + 4, textY, 12, Color::TextPrimary());

    if (measureText(filename, 12) > maxW) {
        std::string remaining = filename;
        // Simple approximation for second line
        size_t half = filename.length() / 2;
        std::string line2 = truncateText(filename.substr(half), maxW, 12);
        if (line2 != "…") {
            drawText(canvas, line2, bounds.x + 4, textY + 14, 12, Color::TextPrimary());
        }
    }
}

bool UIFileItem::onMouseUp(float x, float y, int button) {
    if (!hitTest(x, y)) return false;
    if (button == 2) { // Right click
        if (onRightClick) onRightClick();
        return true;
    }
    if (button == 0) {
        auto now = std::chrono::steady_clock::now();
        float ms = std::chrono::duration<float, std::milli>(now - lastClick_).count();
        if (ms < 400 && clickCount_ == 1) {
            clickCount_ = 0;
            if (onDoubleClick) onDoubleClick();
        } else {
            clickCount_ = 1;
            lastClick_ = now;
            isSelected = !isSelected;
        }
        return true;
    }
    return false;
}

bool UIFileItem::onMouseMove(float x, float y) {
    bool old = hovered; hovered = hitTest(x, y); return old != hovered;
}

// =============================================================================
// UICategoryCard
// =============================================================================
void UICategoryCard::paint(SkCanvas* canvas) {
    if (!visible) return;

    // Card background
    SkPaint bg = fillPaint(Color::CardBg());
    drawRR(canvas, bounds, cornerRadius, bg);

    if (hovered) {
        SkPaint hov;
        hov.setAntiAlias(true);
        hov.setColor(Color::HoverBg().toSkia());
        drawRR(canvas, bounds, cornerRadius, hov);
    }

    // Border
    drawRR(canvas, bounds, cornerRadius, strokePaint(Color::Border()));

    // Icon circle background
    float circleR = iconSize * 0.55f;
    float cx = bounds.centerX();
    float cy = bounds.y + 20 + circleR;
    SkPaint circlePaint;
    circlePaint.setAntiAlias(true);
    circlePaint.setColor(accentColor.withAlpha(20).toSkia());
    canvas->drawCircle(cx, cy, circleR, circlePaint);

    // Icon
    drawText(canvas, iconUnicode, cx - iconSize * 0.4f, cy + iconSize * 0.3f, iconSize, accentColor);

    // Title
    float titleY = cy + circleR + 18;
    float tw = measureText(title, 13);
    drawText(canvas, title, bounds.centerX() - tw / 2, titleY, 13, Color::TextPrimary(), true);

    // Description
    float descY = titleY + 18;
    std::string desc1 = truncateText(description, bounds.w - 16, 11);
    drawText(canvas, desc1, bounds.centerX() - measureText(desc1, 11) / 2, descY, 11, Color::TextSecondary());
}

bool UICategoryCard::onMouseUp(float x, float y, int button) {
    if (hitTest(x, y) && button == 0 && onClick) { onClick(); return true; }
    return false;
}

bool UICategoryCard::onMouseMove(float x, float y) {
    bool old = hovered; hovered = hitTest(x, y); return old != hovered;
}

// =============================================================================
// UIWallpaperCard
// =============================================================================
void UIWallpaperCard::paint(SkCanvas* canvas) {
    if (!visible) return;

    SkRRect rr = SkRRect::MakeRectXY(SkRect::MakeXYWH(bounds.x, bounds.y, bounds.w, bounds.h), cornerRadius, cornerRadius);

    if (thumbnail) {
        SkPaint imgPaint;
        imgPaint.setAntiAlias(true);
        canvas->clipRRect(rr, true);
        canvas->drawImageRect(thumbnail.get(), SkRect::MakeXYWH(bounds.x, bounds.y, bounds.w, bounds.h),
                              SkSamplingOptions(), &imgPaint);
        canvas->restore();
    } else {
        SkPaint fb = fillPaint(fallbackColor);
        canvas->drawRRect(rr, fb);
    }

    if (isSelected) {
        SkPaint sel = strokePaint(Color::AccentBlue(), 3.0f);
        canvas->drawRRect(rr, sel);

        // Checkmark
        SkPaint check;
        check.setAntiAlias(true);
        check.setColor(SK_ColorWHITE);
        float cx = bounds.right() - 14;
        float cy = bounds.y + 14;
        canvas->drawCircle(cx, cy, 10, check);
        check.setColor(Color::AccentBlue().toSkia());
        check.setStrokeWidth(2);
        canvas->drawLine(cx - 3, cy, cx - 1, cy + 3, check);
        canvas->drawLine(cx - 1, cy + 3, cx + 4, cy - 3, check);
    } else if (hovered) {
        canvas->drawRRect(rr, strokePaint(Color::AccentBlue().withAlpha(100), 2.0f));
    }

    if (!label.empty()) {
        SkPaint labelBg;
        labelBg.setAntiAlias(true);
        labelBg.setColor(SkColorSetARGB(180, 0, 0, 0));
        canvas->drawRect(SkRect::MakeXYWH(bounds.x, bounds.bottom() - 24, bounds.w, 24), labelBg);
        drawText(canvas, label, bounds.x + 8, bounds.bottom() - 6, 11, Color::fromHex(0xFFFFFF));
    }
}

bool UIWallpaperCard::onMouseUp(float x, float y, int button) {
    if (hitTest(x, y) && button == 0) {
        isSelected = true;
        if (onClick) onClick();
        return true;
    }
    return false;
}

bool UIWallpaperCard::onMouseMove(float x, float y) {
    bool old = hovered; hovered = hitTest(x, y); return old != hovered;
}

// =============================================================================
// UISidebarItem
// =============================================================================
void UISidebarItem::paint(SkCanvas* canvas) {
    if (!visible) return;

    if (isSelected || hovered) {
        SkPaint bg = fillPaint(isSelected ? Color::ActiveBg() : Color::HoverBg());
        drawRR(canvas, bounds, cornerRadius, bg);
    }

    if (!iconUnicode.empty()) {
        drawText(canvas, iconUnicode, bounds.x + 12, bounds.centerY() + 6, 16, iconColor);
    }
    drawText(canvas, label, bounds.x + 38, bounds.centerY() + fontSize * 0.35f, fontSize,
             isSelected ? Color::AccentBlue() : textColor, isSelected);
}

bool UISidebarItem::onMouseUp(float x, float y, int button) {
    if (hitTest(x, y) && button == 0) {
        isSelected = true;
        if (onClick) onClick();
        return true;
    }
    return false;
}

bool UISidebarItem::onMouseMove(float x, float y) {
    bool old = hovered; hovered = hitTest(x, y); return old != hovered;
}

// =============================================================================
// UIContainer
// =============================================================================
void UIContainer::addChild(WidgetPtr child) {
    children.push_back(child);
}

void UIContainer::removeChild(WidgetPtr child) {
    children.erase(std::remove(children.begin(), children.end(), child), children.end());
}

void UIContainer::clearChildren() {
    children.clear();
}

void UIContainer::paint(SkCanvas* canvas) {
    if (!visible) return;
    if (bgColor.a > 0) {
        SkPaint p = fillPaint(bgColor);
        drawRR(canvas, bounds, cornerRadius, p);
    }
    for (auto& c : children) {
        if (c->visible) c->paint(canvas);
    }
}

WidgetPtr UIContainer::hitTestRecursive(float x, float y) {
    if (!visible || !bounds.contains(x, y)) return nullptr;
    for (auto it = children.rbegin(); it != children.rend(); ++it) {
        if ((*it)->visible && (*it)->bounds.contains(x, y)) {
            if (auto* container = dynamic_cast<UIContainer*>(it->get())) {
                auto found = container->hitTestRecursive(x, y);
                if (found) return found;
            }
            return *it;
        }
    }
    return nullptr;
}

bool UIContainer::onMouseMove(float x, float y) {
    bool handled = false;
    for (auto& c : children) {
        if (c->visible && c->onMouseMove(x, y)) handled = true;
    }
    return handled;
}

bool UIContainer::onMouseDown(float x, float y, int button) {
    auto target = hitTestRecursive(x, y);
    if (target) return target->onMouseDown(x, y, button);
    return false;
}

bool UIContainer::onMouseUp(float x, float y, int button) {
    auto target = hitTestRecursive(x, y);
    if (target) return target->onMouseUp(x, y, button);
    return false;
}

bool UIContainer::onScroll(float dx, float dy) {
    for (auto& c : children) {
        if (c->visible && c->onScroll(dx, dy)) return true;
    }
    return false;
}

} // namespace agro
