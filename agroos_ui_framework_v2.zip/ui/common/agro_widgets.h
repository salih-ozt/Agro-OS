#pragma once

#include <string>
#include <vector>
#include <functional>
#include <memory>
#include <chrono>

#include "include/core/SkCanvas.h"
#include "include/core/SkPaint.h"
#include "include/core/SkFont.h"
#include "include/core/SkTextBlob.h"
#include "include/core/SkRRect.h"
#include "include/core/SkPath.h"
#include "include/core/SkImage.h"

#include "agro_math.h"

namespace agro {

// =============================================================================
// Base Widget
// =============================================================================
class UIWidget {
public:
    UIWidget() = default;
    virtual ~UIWidget() = default;

    Rect bounds;
    bool visible = true;
    bool enabled = true;
    bool hovered = false;
    bool pressed = false;
    bool focused = false;
    std::string tag;

    virtual void paint(SkCanvas* canvas) {}
    virtual bool hitTest(float x, float y) const { return visible && bounds.contains(x, y); }
    virtual bool onMouseMove(float x, float y) { return false; }
    virtual bool onMouseDown(float x, float y, int button) { return false; }
    virtual bool onMouseUp(float x, float y, int button) { return false; }
    virtual bool onScroll(float dx, float dy) { return false; }
    virtual bool onKey(uint32_t key, bool pressed) { return false; }
    virtual bool onTextInput(const std::string& text) { return false; }
};

using WidgetPtr = std::shared_ptr<UIWidget>;

// =============================================================================
// UILabel
// =============================================================================
class UILabel : public UIWidget {
public:
    std::string text;
    Color color = Color::TextPrimary();
    float fontSize = 14.0f;
    bool bold = false;
    int maxLines = 1;
    std::string ellipsis = "…";

    void paint(SkCanvas* canvas) override;
    float measuredWidth() const;
};

// =============================================================================
// UIButton
// =============================================================================
class UIButton : public UIWidget {
public:
    std::string text;
    std::string icon; // Unicode or text icon
    Color bgColor = Color::fromHex(0xFFFFFF, 0);
    Color hoverColor = Color::HoverBg();
    Color activeColor = Color::ActiveBg();
    Color textColor = Color::TextPrimary();
    float fontSize = 13.0f;
    float cornerRadius = 6.0f;
    std::function<void()> onClick;

    void paint(SkCanvas* canvas) override;
    bool onMouseDown(float x, float y, int button) override;
    bool onMouseUp(float x, float y, int button) override;
    bool onMouseMove(float x, float y) override;
};

// =============================================================================
// UIIconButton (Toolbar buttons)
// =============================================================================
class UIIconButton : public UIWidget {
public:
    std::string icon;
    float iconSize = 18.0f;
    Color iconColor = Color::TextPrimary();
    Color hoverBg = Color::HoverBg();
    Color activeBg = Color::ActiveBg();
    float cornerRadius = 6.0f;
    std::function<void()> onClick;

    void paint(SkCanvas* canvas) override;
    bool onMouseDown(float x, float y, int button) override;
    bool onMouseUp(float x, float y, int button) override;
    bool onMouseMove(float x, float y) override;
};

// =============================================================================
// UITextInput
// =============================================================================
class UITextInput : public UIWidget {
public:
    std::string text;
    std::string placeholder;
    Color bgColor = Color::fromHex(0xFFFFFF, 100);
    Color borderColor = Color::Border();
    Color textColor = Color::TextPrimary();
    Color placeholderColor = Color::TextTertiary();
    float fontSize = 13.0f;
    float cornerRadius = 8.0f;
    int maxLength = 256;
    std::function<void(const std::string&)> onChange;
    std::function<void()> onSubmit;

    void paint(SkCanvas* canvas) override;
    bool onMouseDown(float x, float y, int button) override;
    bool onKey(uint32_t key, bool pressed) override;
    bool onTextInput(const std::string& t) override;
    void insertText(const std::string& t);
    void deleteBackward();

private:
    size_t cursorPos_ = 0;
    float scrollOffset_ = 0;
    std::chrono::steady_clock::time_point focusTime_;
};

// =============================================================================
// UISwitch (Toggle)
// =============================================================================
class UISwitch : public UIWidget {
public:
    bool checked = false;
    Color trackOff = Color::ToggleOff();
    Color trackOn = Color::ToggleOn();
    Color thumbColor = Color::fromHex(0xFFFFFF);
    std::function<void(bool)> onChange;

    void paint(SkCanvas* canvas) override;
    bool onMouseUp(float x, float y, int button) override;
    bool onMouseMove(float x, float y) override;

private:
    float animProgress_ = 0.0f;
    std::chrono::steady_clock::time_point toggleTime_;
    float getAnimatedProgress() const;
};

// =============================================================================
// UISlider
// =============================================================================
class UISlider : public UIWidget {
public:
    float value = 0.0f; // 0.0 - 1.0
    float minValue = 0.0f;
    float maxValue = 1.0f;
    Color trackColor = Color::TrackBg();
    Color fillColor = Color::AccentBlue();
    Color thumbColor = Color::fromHex(0xFFFFFF);
    float trackHeight = 4.0f;
    float thumbRadius = 8.0f;
    std::function<void(float)> onChange;

    void paint(SkCanvas* canvas) override;
    bool onMouseDown(float x, float y, int button) override;
    bool onMouseMove(float x, float y) override;
    bool onMouseUp(float x, float y, int button) override;

private:
    bool dragging_ = false;
    float valueFromPos(float x) const;
};

// =============================================================================
// UIDropdown
// =============================================================================
class UIDropdown : public UIWidget {
public:
    std::vector<std::string> options;
    int selectedIndex = 0;
    std::string placeholder = "Select...";
    Color bgColor = Color::fromHex(0xFFFFFF, 100);
    Color textColor = Color::TextPrimary();
    float fontSize = 13.0f;
    float cornerRadius = 8.0f;
    std::function<void(int, const std::string&)> onSelect;

    void paint(SkCanvas* canvas) override;
    bool onMouseUp(float x, float y, int button) override;
    bool onMouseMove(float x, float y) override;
    void closeDropdown();

private:
    bool expanded_ = false;
    int hoverIndex_ = -1;
};

// =============================================================================
// UIContextMenu
// =============================================================================
class UIContextMenu : public UIWidget {
public:
    struct Item {
        std::string label;
        std::string shortcut;
        bool separator = false;
        bool enabled = true;
        std::function<void()> action;
    };
    std::vector<Item> items;
    float itemHeight = 32.0f;
    float cornerRadius = 8.0f;
    Color bgColor = Color::fromHex(0xFFFFFF, 240);
    Color hoverColor = Color::HoverBg();
    Color textColor = Color::TextPrimary();
    Color shortcutColor = Color::TextTertiary();
    float fontSize = 13.0f;

    void show(float x, float y);
    void hide();
    bool isVisible() const { return visible; }

    void paint(SkCanvas* canvas) override;
    bool onMouseMove(float x, float y) override;
    bool onMouseUp(float x, float y, int button) override;

private:
    int hoverIndex_ = -1;
    void updateBounds();
};

// =============================================================================
// UIFileItem (File Manager Grid Item)
// =============================================================================
class UIFileItem : public UIWidget {
public:
    std::string filename;
    bool isDirectory = false;
    bool isSelected = false;
    bool isHidden = false;
    uint64_t fileSize = 0;
    std::string modifiedDate;
    Color folderColor = Color::FolderYellow();
    Color folderDark = Color::FolderYellowDark();
    Color fileColor = Color::TextSecondary();
    float iconSize = 56.0f;
    float cornerRadius = 8.0f;
    std::function<void()> onDoubleClick;
    std::function<void()> onRightClick;

    void paint(SkCanvas* canvas) override;
    bool onMouseUp(float x, float y, int button) override;
    bool onMouseMove(float x, float y) override;

private:
    std::chrono::steady_clock::time_point lastClick_;
    int clickCount_ = 0;
    void drawFolderIcon(SkCanvas* canvas, float cx, float cy, float size);
    void drawFileIcon(SkCanvas* canvas, float cx, float cy, float size);
};

// =============================================================================
// UICategoryCard (Settings Overview)
// =============================================================================
class UICategoryCard : public UIWidget {
public:
    std::string title;
    std::string description;
    std::string iconUnicode; // e.g. "💻" or custom
    Color accentColor = Color::AccentBlue();
    float iconSize = 48.0f;
    float cornerRadius = 12.0f;
    std::function<void()> onClick;

    void paint(SkCanvas* canvas) override;
    bool onMouseUp(float x, float y, int button) override;
    bool onMouseMove(float x, float y) override;
};

// =============================================================================
// UIWallpaperCard
// =============================================================================
class UIWallpaperCard : public UIWidget {
public:
    std::string label;
    bool isSelected = false;
    sk_sp<SkImage> thumbnail;
    Color fallbackColor = Color::AccentBlue();
    float cornerRadius = 8.0f;
    std::function<void()> onClick;

    void paint(SkCanvas* canvas) override;
    bool onMouseUp(float x, float y, int button) override;
    bool onMouseMove(float x, float y) override;
};

// =============================================================================
// UISidebarItem
// =============================================================================
class UISidebarItem : public UIWidget {
public:
    std::string label;
    std::string iconUnicode;
    bool isSelected = false;
    bool isActive = false;
    Color iconColor = Color::AccentBlue();
    Color textColor = Color::TextPrimary();
    float fontSize = 13.0f;
    float cornerRadius = 6.0f;
    std::function<void()> onClick;

    void paint(SkCanvas* canvas) override;
    bool onMouseUp(float x, float y, int button) override;
    bool onMouseMove(float x, float y) override;
};

// =============================================================================
// UIContainer (Base for panels)
// =============================================================================
class UIContainer : public UIWidget {
public:
    std::vector<WidgetPtr> children;
    Color bgColor = Color::fromHex(0x000000, 0);
    float cornerRadius = 0;

    void addChild(WidgetPtr child);
    void removeChild(WidgetPtr child);
    void clearChildren();

    void paint(SkCanvas* canvas) override;
    bool onMouseMove(float x, float y) override;
    bool onMouseDown(float x, float y, int button) override;
    bool onMouseUp(float x, float y, int button) override;
    bool onScroll(float dx, float dy) override;

    WidgetPtr hitTestRecursive(float x, float y);
};

} // namespace agro
