#include "agro_layout.h"
#include <cmath>

namespace agro {

void FlexLayout::apply(const Rect& container, const std::vector<WidgetPtr>& widgets) {
    float x = container.x + padding;
    float y = container.y + padding;
    float availW = container.w - padding * 2;
    float availH = container.h - padding * 2;

    float totalFixed = 0;
    int flexCount = 0;
    for (auto& w : widgets) {
        if (!w->visible) continue;
        if (direction == LayoutDirection::Horizontal) {
            totalFixed += w->bounds.w + gap;
            if (w->bounds.w <= 0) flexCount++;
        } else {
            totalFixed += w->bounds.h + gap;
            if (w->bounds.h <= 0) flexCount++;
        }
    }
    if (!widgets.empty()) totalFixed -= gap;

    float flexSize = 0;
    if (flexCount > 0) {
        float remaining = (direction == LayoutDirection::Horizontal ? availW : availH) - totalFixed;
        flexSize = std::max(0.0f, remaining / flexCount);
    }

    // Justify offset
    float offset = 0;
    float totalUsed = totalFixed + flexCount * flexSize;
    if (justify == JustifyContent::Center) {
        offset = ((direction == LayoutDirection::Horizontal ? availW : availH) - totalUsed) / 2;
    } else if (justify == JustifyContent::End) {
        offset = (direction == LayoutDirection::Horizontal ? availW : availH) - totalUsed;
    }

    if (direction == LayoutDirection::Horizontal) {
        x += offset;
        for (auto& w : widgets) {
            if (!w->visible) continue;
            if (w->bounds.w <= 0) w->bounds.w = flexSize;
            w->bounds.x = x;
            if (alignItems == AlignItems::Center) {
                w->bounds.y = container.y + (container.h - w->bounds.h) / 2;
            } else if (alignItems == AlignItems::End) {
                w->bounds.y = container.bottom() - padding - w->bounds.h;
            } else {
                w->bounds.y = y;
            }
            x += w->bounds.w + gap;
        }
    } else {
        y += offset;
        for (auto& w : widgets) {
            if (!w->visible) continue;
            if (w->bounds.h <= 0) w->bounds.h = flexSize;
            w->bounds.y = y;
            if (alignItems == AlignItems::Center) {
                w->bounds.x = container.x + (container.w - w->bounds.w) / 2;
            } else if (alignItems == AlignItems::End) {
                w->bounds.x = container.right() - padding - w->bounds.w;
            } else {
                w->bounds.x = x;
            }
            y += w->bounds.h + gap;
        }
    }
}

void GridLayout::apply(const Rect& container, const std::vector<WidgetPtr>& widgets) {
    float x = container.x + padding;
    float y = container.y + padding;
    int col = 0;

    for (auto& w : widgets) {
        if (!w->visible) continue;
        w->bounds.x = x;
        w->bounds.y = y;
        w->bounds.w = itemWidth;
        w->bounds.h = itemHeight;

        col++;
        if (col >= columns) {
            col = 0;
            x = container.x + padding;
            y += itemHeight + gapY;
        } else {
            x += itemWidth + gapX;
        }
    }
}

int GridLayout::visibleRows(const Rect& container, int itemCount) const {
    int vis = 0;
    for (auto& w : itemCount) { /* dummy */ }
    int rows = itemCount / columns;
    if (itemCount % columns != 0) rows++;
    return rows;
}

void SidebarLayout::apply(const Rect& container, WidgetPtr sidebar, WidgetPtr content) {
    if (sidebar) {
        sidebar->bounds = Rect(container.x, container.y, sidebarWidth, container.h);
    }
    if (content) {
        content->bounds = Rect(container.x + sidebarWidth + gap, container.y,
                               container.w - sidebarWidth - gap, container.h);
    }
}

} // namespace agro
