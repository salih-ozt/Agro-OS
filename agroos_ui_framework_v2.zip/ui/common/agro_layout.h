#pragma once

#include <vector>
#include <memory>
#include "agro_widgets.h"

namespace agro {

enum class LayoutDirection { Horizontal, Vertical };
enum class AlignItems { Start, Center, End, Stretch };
enum class JustifyContent { Start, Center, End, SpaceBetween, SpaceAround };

// =============================================================================
// FlexLayout
// =============================================================================
class FlexLayout {
public:
    LayoutDirection direction = LayoutDirection::Horizontal;
    AlignItems alignItems = AlignItems::Center;
    JustifyContent justify = JustifyContent::Start;
    float gap = 8.0f;
    float padding = 0.0f;

    void apply(const Rect& container, const std::vector<WidgetPtr>& widgets);
};

// =============================================================================
// GridLayout
// =============================================================================
class GridLayout {
public:
    int columns = 4;
    float itemWidth = 96.0f;
    float itemHeight = 96.0f;
    float gapX = 16.0f;
    float gapY = 16.0f;
    float padding = 16.0f;

    void apply(const Rect& container, const std::vector<WidgetPtr>& widgets);
    int visibleRows(const Rect& container, int itemCount) const;
};

// =============================================================================
// SidebarLayout
// =============================================================================
class SidebarLayout {
public:
    float sidebarWidth = 220.0f;
    float gap = 0;

    void apply(const Rect& container, WidgetPtr sidebar, WidgetPtr content);
};

} // namespace agro
