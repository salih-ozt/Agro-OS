#pragma once

#include <cstdint>
#include <cmath>
#include <algorithm>

// Skia Color helper
#include "include/core/SkColor.h"

namespace agro {

struct Vec2 {
    float x = 0.0f, y = 0.0f;
    Vec2() = default;
    Vec2(float x_, float y_) : x(x_), y(y_) {}
    Vec2 operator+(const Vec2& o) const { return Vec2(x + o.x, y + o.y); }
    Vec2 operator-(const Vec2& o) const { return Vec2(x - o.x, y - o.y); }
};

struct Rect {
    float x = 0, y = 0, w = 0, h = 0;
    Rect() = default;
    Rect(float x_, float y_, float w_, float h_) : x(x_), y(y_), w(w_), h(h_) {}
    bool contains(float px, float py) const {
        return px >= x && px <= x + w && py >= y && py <= y + h;
    }
    bool contains(const Vec2& p) const { return contains(p.x, p.y); }
    float right() const { return x + w; }
    float bottom() const { return y + h; }
    float centerX() const { return x + w * 0.5f; }
    float centerY() const { return y + h * 0.5f; }
    Vec2 center() const { return Vec2(centerX(), centerY()); }
    Rect inset(float dx, float dy) const { return Rect(x + dx, y + dy, w - dx * 2, h - dy * 2); }
    Rect outset(float dx, float dy) const { return Rect(x - dx, y - dy, w + dx * 2, h + dy * 2); }
    Rect translated(float dx, float dy) const { return Rect(x + dx, y + dy, w, h); }
};

struct Color {
    uint8_t r = 0, g = 0, b = 0, a = 255;
    Color() = default;
    Color(uint8_t r_, uint8_t g_, uint8_t b_, uint8_t a_ = 255)
        : r(r_), g(g_), b(b_), a(a_) {}

    static Color fromHex(uint32_t hex, uint8_t alpha = 255) {
        return Color(
            static_cast<uint8_t>((hex >> 16) & 0xFF),
            static_cast<uint8_t>((hex >> 8) & 0xFF),
            static_cast<uint8_t>(hex & 0xFF),
            alpha
        );
    }
    static Color fromRGBA(uint8_t r_, uint8_t g_, uint8_t b_, uint8_t a_) {
        return Color(r_, g_, b_, a_);
    }
    static Color fromSkia(SkColor c) {
        return Color(SkColorGetR(c), SkColorGetG(c), SkColorGetB(c), SkColorGetA(c));
    }

    SkColor toSkia() const {
        return SkColorSetARGB(a, r, g, b);
    }

    Color withAlpha(uint8_t newAlpha) const {
        return Color(r, g, b, newAlpha);
    }

    Color darken(float amount) const {
        return Color(
            static_cast<uint8_t>(std::max(0.0f, r * (1.0f - amount))),
            static_cast<uint8_t>(std::max(0.0f, g * (1.0f - amount))),
            static_cast<uint8_t>(std::max(0.0f, b * (1.0f - amount))),
            a
        );
    }

    Color lighten(float amount) const {
        return Color(
            static_cast<uint8_t>(std::min(255.0f, r + (255 - r) * amount)),
            static_cast<uint8_t>(std::min(255.0f, g + (255 - g) * amount)),
            static_cast<uint8_t>(std::min(255.0f, b + (255 - b) * amount)),
            a
        );
    }

    static Color lerp(const Color& a, const Color& b, float t) {
        return Color(
            static_cast<uint8_t>(a.r + (b.r - a.r) * t),
            static_cast<uint8_t>(a.g + (b.g - a.g) * t),
            static_cast<uint8_t>(a.b + (b.b - a.b) * t),
            static_cast<uint8_t>(a.a + (b.a - a.a) * t)
        );
    }

    // Preset colors matching the AgroOS visual design
    static Color AcrylicPanel() { return fromHex(0xFFFFFF, 180); }
    static Color AcrylicSidebar() { return fromHex(0xF5F5F5, 200); }
    static Color AccentBlue() { return fromHex(0x0078D4); }
    static Color TextPrimary() { return fromHex(0x1A1A1A); }
    static Color TextSecondary() { return fromHex(0x5F5F5F); }
    static Color TextTertiary() { return fromHex(0x8A8A8A); }
    static Color Border() { return fromHex(0x000000, 12); }
    static Color HoverBg() { return fromHex(0x0078D4, 20); }
    static Color ActiveBg() { return fromHex(0x0078D4, 35); }
    static Color FolderYellow() { return fromHex(0xFFD54F); }
    static Color FolderYellowDark() { return fromHex(0xFFB300); }
    static Color Success() { return fromHex(0x2EA043); }
    static Color Danger() { return fromHex(0xCF222E); }
    static Color Warning() { return fromHex(0xD4A72C); }
    static Color Shadow() { return fromHex(0x000000, 40); }
    static Color CardBg() { return fromHex(0xFFFFFF, 200); }
    static Color ToggleOff() { return fromHex(0xCCCCCC); }
    static Color ToggleOn() { return fromHex(0x0078D4); }
    static Color TrackBg() { return fromHex(0xE5E5E5); }
};

} // namespace agro
