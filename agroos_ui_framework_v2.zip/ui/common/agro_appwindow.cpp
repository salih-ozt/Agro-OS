#include "agro_appwindow.h"
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <linux/memfd.h>
#include <sys/syscall.h>
#include <cmath>

namespace agro {

// =============================================================================
// Wayland Listener Tables
// =============================================================================
static const wl_registry_listener registryListener = {
    .global = AppWindow::registryGlobalCb,
    .global_remove = AppWindow::registryGlobalRemoveCb
};

static const xdg_wm_base_listener xdgWmBaseListener = {
    .ping = AppWindow::xdgWmBasePingCb
};

static const xdg_surface_listener xdgSurfaceListener = {
    .configure = AppWindow::xdgSurfaceConfigureCb
};

static const xdg_toplevel_listener xdgToplevelListener = {
    .configure = AppWindow::xdgToplevelConfigureCb,
    .close = AppWindow::xdgToplevelCloseCb
};

static const wl_seat_listener seatListener = {
    .capabilities = AppWindow::seatCapabilitiesCb,
    .name = AppWindow::seatNameCb
};

static const wl_pointer_listener pointerListener = {
    .enter = AppWindow::pointerEnterCb,
    .leave = AppWindow::pointerLeaveCb,
    .motion = AppWindow::pointerMotionCb,
    .button = AppWindow::pointerButtonCb,
    .axis = AppWindow::pointerAxisCb,
    .frame = AppWindow::pointerFrameCb,
    .axis_source = AppWindow::pointerAxisSourceCb,
    .axis_stop = AppWindow::pointerAxisStopCb,
    .axis_discrete = AppWindow::pointerAxisDiscreteCb
};

static const wl_buffer_listener bufferListener = {
    .release = AppWindow::bufferReleaseCb
};

// =============================================================================
// Constructor / Destructor
// =============================================================================
AppWindow::AppWindow(const std::string& title, int width, int height)
    : title_(title), bounds_{0, 0, width, height}, pendingBounds_{0, 0, width, height} {
    startupTime_ = std::chrono::steady_clock::now();
}

AppWindow::~AppWindow() {
    shutdown();
}

// =============================================================================
// Initialization
// =============================================================================
bool AppWindow::initialize() {
    display_ = wl_display_connect(nullptr);
    if (!display_) {
        fprintf(stderr, "[AppWindow] Failed to connect to Wayland display\n");
        return false;
    }

    registry_ = wl_display_get_registry(display_);
    wl_registry_add_listener(registry_, &registryListener, this);
    wl_display_roundtrip(display_);

    if (!compositor_ || !xdgWmBase_ || !shm_) {
        fprintf(stderr, "[AppWindow] Required Wayland globals not available\n");
        return false;
    }

    surface_ = wl_compositor_create_surface(compositor_);
    xdgSurface_ = xdg_wm_base_get_xdg_surface(xdgWmBase_, surface_);
    xdg_toplevel_add_listener(xdgToplevel_, &xdgToplevelListener, this);
    xdg_surface_add_listener(xdgSurface_, &xdgSurfaceListener, this);

    xdg_toplevel_set_title(xdgToplevel_, title_.c_str());
    xdg_toplevel_set_app_id(xdgToplevel_, "org.agroos.app");

    wl_surface_commit(surface_);
    wl_display_roundtrip(display_);

    if (!createShmBuffer(bounds_.width, bounds_.height)) {
        fprintf(stderr, "[AppWindow] Failed to create SHM buffer\n");
        return false;
    }

    running_ = true;
    return true;
}

void AppWindow::shutdown() {
    running_ = false;
    destroyShmBuffer();
    if (xdgToplevel_) { xdg_toplevel_destroy(xdgToplevel_); xdgToplevel_ = nullptr; }
    if (xdgSurface_) { xdg_surface_destroy(xdgSurface_); xdgSurface_ = nullptr; }
    if (surface_) { wl_surface_destroy(surface_); surface_ = nullptr; }
    if (pointer_) { wl_pointer_destroy(pointer_); pointer_ = nullptr; }
    if (seat_) { wl_seat_destroy(seat_); seat_ = nullptr; }
    if (shm_) { wl_shm_destroy(shm_); shm_ = nullptr; }
    if (compositor_) { wl_compositor_destroy(compositor_); compositor_ = nullptr; }
    if (registry_) { wl_registry_destroy(registry_); registry_ = nullptr; }
    if (display_) { wl_display_disconnect(display_); display_ = nullptr; }
}

// =============================================================================
// Event Loop
// =============================================================================
void AppWindow::runEventLoop() {
    while (running_ && wl_display_dispatch(display_) != -1) {
        if (needsRedraw_ && skSurface_) {
            needsRedraw_ = false;
            SkCanvas* canvas = skSurface_->getCanvas();
            if (canvas) {
                canvas->clear(SK_ColorTRANSPARENT);
                drawWindowChrome(canvas);
                onPaint(canvas);
                canvas->flush();
                wl_surface_attach(surface_, buffer_, 0, 0);
                wl_surface_damage_buffer(surface_, 0, 0, bounds_.width, bounds_.height);
                wl_surface_commit(surface_);
            }
        }
    }
}

void AppWindow::requestClose() {
    isClosed_ = true;
    running_ = false;
}

void AppWindow::requestRedraw() {
    needsRedraw_ = true;
}

// =============================================================================
// Buffer Management
// =============================================================================
int AppWindow::createAnonymousFile(size_t size) {
    int fd = syscall(SYS_memfd_create, "agro-shm", MFD_CLOEXEC | MFD_ALLOW_SEALING);
    if (fd < 0) {
        char name[] = "/dev/shm/agro-wayland-XXXXXX";
        fd = mkstemp(name);
        if (fd >= 0) unlink(name);
    }
    if (fd >= 0) {
        if (ftruncate(fd, size) < 0) {
            close(fd);
            return -1;
        }
    }
    return fd;
}

bool AppWindow::createShmBuffer(int width, int height) {
    destroyShmBuffer();

    const int stride = width * 4;
    shmSize_ = stride * height;

    shmFd_ = createAnonymousFile(shmSize_);
    if (shmFd_ < 0) return false;

    shmData_ = mmap(nullptr, shmSize_, PROT_READ | PROT_WRITE, MAP_SHARED, shmFd_, 0);
    if (shmData_ == MAP_FAILED) {
        close(shmFd_);
        shmFd_ = -1;
        return false;
    }

    bitmap_.allocN32Pixels(width, height);
    skSurface_ = SkSurface::MakeRasterDirect(
        SkImageInfo::MakeN32Premul(width, height),
        bitmap_.getPixels(), bitmap_.rowBytes()
    );

    wl_shm_pool* pool = wl_shm_create_pool(shm_, shmFd_, shmSize_);
    buffer_ = wl_shm_pool_create_buffer(pool, 0, width, height, stride, WL_SHM_FORMAT_ARGB8888);
    wl_shm_pool_destroy(pool);
    wl_buffer_add_listener(buffer_, &bufferListener, this);

    return true;
}

void AppWindow::destroyShmBuffer() {
    if (buffer_) { wl_buffer_destroy(buffer_); buffer_ = nullptr; }
    skSurface_.reset();
    bitmap_.reset();
    if (shmData_ && shmData_ != MAP_FAILED) {
        munmap(shmData_, shmSize_);
        shmData_ = nullptr;
    }
    if (shmFd_ >= 0) { close(shmFd_); shmFd_ = -1; }
    shmSize_ = 0;
}

// =============================================================================
// Window Chrome Drawing
// =============================================================================
void AppWindow::drawWindowChrome(SkCanvas* canvas) {
    drawDropShadow(canvas);
    drawAcrylicBackground(canvas);
    drawTitleBar(canvas);
}

void AppWindow::drawDropShadow(SkCanvas* canvas) {
    SkPaint shadowPaint;
    shadowPaint.setAntiAlias(true);
    shadowPaint.setColor(Color::Shadow().toSkia());
    shadowPaint.setMaskFilter(SkMaskFilter::MakeBlur(kNormal_SkBlurStyle, 25.0f));

    SkRRect outer = SkRRect::MakeRectXY(
        SkRect::MakeXYWH(-8, -8, bounds_.width + 16, bounds_.height + 16),
        kWindowRadius + 8, kWindowRadius + 8
    );
    canvas->drawRRect(outer, shadowPaint);
}

void AppWindow::drawAcrylicBackground(SkCanvas* canvas) {
    // Main acrylic panel
    SkRRect rr = SkRRect::MakeRectXY(
        SkRect::MakeWH(bounds_.width, bounds_.height),
        kWindowRadius, kWindowRadius
    );

    // Base semi-transparent white
    SkPaint acrylicPaint;
    acrylicPaint.setAntiAlias(true);
    acrylicPaint.setColor(Color::AcrylicPanel().toSkia());
    canvas->drawRRect(rr, acrylicPaint);

    // Subtle noise/texture overlay (simulated with secondary layer)
    SkPaint noisePaint;
    noisePaint.setAntiAlias(true);
    noisePaint.setColor(SkColorSetARGB(8, 255, 255, 255));
    canvas->drawRRect(rr, noisePaint);

    // 1px border
    SkPaint borderPaint;
    borderPaint.setAntiAlias(true);
    borderPaint.setStyle(SkPaint::kStroke_Style);
    borderPaint.setStrokeWidth(1.0f);
    borderPaint.setColor(Color::Border().toSkia());
    canvas->drawRRect(rr, borderPaint);
}

void AppWindow::drawTitleBar(SkCanvas* canvas) {
    // Title tab pill
    drawTitleTab(canvas);
    // Window controls
    drawWindowControls(canvas);
}

void AppWindow::drawTitleTab(SkCanvas* canvas) {
    float tabX = 16;
    float tabY = 8;

    SkRRect tabRR = SkRRect::MakeRectXY(
        SkRect::MakeXYWH(tabX, tabY, kTabWidth, kTabHeight),
        8, 8
    );

    SkPaint tabPaint;
    tabPaint.setAntiAlias(true);
    tabPaint.setColor(Color::fromHex(0xFFFFFF, 120).toSkia());
    canvas->drawRRect(tabRR, tabPaint);

    // Tab border
    SkPaint tabBorder;
    tabBorder.setAntiAlias(true);
    tabBorder.setStyle(SkPaint::kStroke_Style);
    tabBorder.setStrokeWidth(1);
    tabBorder.setColor(Color::Border().toSkia());
    canvas->drawRRect(tabRR, tabBorder);

    // Tab text
    SkFont font(nullptr, 13);
    font.setSubpixel(true);
    SkPaint textPaint;
    textPaint.setColor(Color::TextPrimary().toSkia());
    textPaint.setAntiAlias(true);

    auto blob = SkTextBlob::MakeFromString(title_.c_str(), font);
    canvas->drawTextBlob(blob.get(), tabX + 12, tabY + 21, textPaint);

    // Close 'x' on tab
    SkPaint closePaint;
    closePaint.setAntiAlias(true);
    closePaint.setStrokeWidth(1.5f);
    closePaint.setColor(Color::TextSecondary().toSkia());
    float cx = tabX + kTabWidth - 16;
    float cy = tabY + kTabHeight / 2;
    canvas->drawLine(cx - 4, cy - 4, cx + 4, cy + 4, closePaint);
    canvas->drawLine(cx + 4, cy - 4, cx - 4, cy + 4, closePaint);

    // '+' new tab button
    SkPaint plusPaint;
    plusPaint.setAntiAlias(true);
    plusPaint.setColor(Color::TextSecondary().toSkia());
    plusPaint.setStrokeWidth(1.5f);
    float px = tabX + kTabWidth + 14;
    float py = tabY + kTabHeight / 2;
    canvas->drawLine(px, py - 5, px, py + 5, plusPaint);
    canvas->drawLine(px - 5, py, px + 5, py, plusPaint);
}

void AppWindow::drawWindowControls(SkCanvas* canvas) {
    int btnY = 15;
    int startX = bounds_.width - 20;

    struct Btn { int x; Color hover; const char* label; };
    Btn buttons[] = {
        { startX - kButtonSize * 2 - kButtonGap * 2, Color::fromHex(0xFFB300), "_" },
        { startX - kButtonSize - kButtonGap, Color::fromHex(0x2EA043), "□" },
        { startX, Color::Danger(), "×" }
    };

    for (const auto& btn : buttons) {
        bool hovered = false;
        if (btn.label[0] == '×') hovered = mouseInClose_;
        else if (btn.label[0] == '□') hovered = mouseInMaximize_;
        else hovered = mouseInMinimize_;

        if (hovered) {
            SkPaint bg;
            bg.setAntiAlias(true);
            bg.setColor(btn.hover.withAlpha(40).toSkia());
            canvas->drawCircle(btn.x, btnY, 12, bg);
        }

        SkPaint paint;
        paint.setAntiAlias(true);
        paint.setColor(Color::TextPrimary().toSkia());
        SkFont font(nullptr, 14);
        auto blob = SkTextBlob::MakeFromString(btn.label, font);
        canvas->drawTextBlob(blob.get(), btn.x - 4, btnY + 5, paint);
    }
}

// =============================================================================
// Hit Testing
// =============================================================================
bool AppWindow::hitTestTitleBar(int x, int y) const {
    return y >= 0 && y <= kTitleBarHeight && x >= 0 && x <= bounds_.width - 80;
}

bool AppWindow::hitTestClose(int x, int y) const {
    int cx = bounds_.width - 20;
    return std::hypot(x - cx, y - 15) <= 12;
}

bool AppWindow::hitTestMaximize(int x, int y) const {
    int cx = bounds_.width - 20 - kButtonSize - kButtonGap;
    return std::hypot(x - cx, y - 15) <= 12;
}

bool AppWindow::hitTestMinimize(int x, int y) const {
    int cx = bounds_.width - 20 - kButtonSize * 2 - kButtonGap * 2;
    return std::hypot(x - cx, y - 15) <= 12;
}

// =============================================================================
// Animation
// =============================================================================
float AppWindow::startupAnimation() const {
    auto now = std::chrono::steady_clock::now();
    float ms = std::chrono::duration<float, std::milli>(now - startupTime_).count();
    float t = std::min(1.0f, ms / 400.0f);
    return easeOutCubic(t);
}

float AppWindow::easeOutCubic(float t) const {
    return 1.0f - std::pow(1.0f - t, 3.0f);
}

void AppWindow::onWindowResize(int width, int height) {
    bounds_.width = width;
    bounds_.height = height;
    createShmBuffer(width, height);
    requestRedraw();
}

// =============================================================================
// Wayland Callbacks
// =============================================================================
void AppWindow::registryGlobalCb(void* data, wl_registry* registry, uint32_t id,
                                 const char* interface, uint32_t version) {
    auto* self = static_cast<AppWindow*>(data);
    if (strcmp(interface, wl_compositor_interface.name) == 0) {
        self->compositor_ = static_cast<wl_compositor*>(wl_registry_bind(registry, id, &wl_compositor_interface, 4));
    } else if (strcmp(interface, wl_shm_interface.name) == 0) {
        self->shm_ = static_cast<wl_shm*>(wl_registry_bind(registry, id, &wl_shm_interface, 1));
    } else if (strcmp(interface, wl_seat_interface.name) == 0) {
        self->seat_ = static_cast<wl_seat*>(wl_registry_bind(registry, id, &wl_seat_interface, 7));
        wl_seat_add_listener(self->seat_, &seatListener, self);
    } else if (strcmp(interface, xdg_wm_base_interface.name) == 0) {
        self->xdgWmBase_ = static_cast<xdg_wm_base*>(wl_registry_bind(registry, id, &xdg_wm_base_interface, 1));
        xdg_wm_base_add_listener(self->xdgWmBase_, &xdgWmBaseListener, self);
    }
}

void AppWindow::registryGlobalRemoveCb(void* data, wl_registry* registry, uint32_t id) {}

void AppWindow::xdgWmBasePingCb(void* data, xdg_wm_base* xdg_wm_base, uint32_t serial) {
    xdg_wm_base_pong(xdg_wm_base, serial);
}

void AppWindow::xdgSurfaceConfigureCb(void* data, xdg_surface* xdg_surface, uint32_t serial) {
    xdg_surface_ack_configure(xdg_surface, serial);
}

void AppWindow::xdgToplevelConfigureCb(void* data, xdg_toplevel* toplevel,
                                       int32_t width, int32_t height, wl_array* states) {
    auto* self = static_cast<AppWindow*>(data);
    if (width > 0 && height > 0) {
        self->onWindowResize(width, height);
    }
    uint32_t* state;
    wl_array_for_each(state, states) {
        if (*state == XDG_TOPLEVEL_STATE_MAXIMIZED) self->state_ = WindowState::Maximized;
        else if (*state == XDG_TOPLEVEL_STATE_FULLSCREEN) self->state_ = WindowState::Fullscreen;
        else if (*state == XDG_TOPLEVEL_STATE_ACTIVATED) self->isActive_ = true;
    }
}

void AppWindow::xdgToplevelCloseCb(void* data, xdg_toplevel* toplevel) {
    static_cast<AppWindow*>(data)->requestClose();
}

void AppWindow::seatCapabilitiesCb(void* data, wl_seat* seat, uint32_t caps) {
    auto* self = static_cast<AppWindow*>(data);
    if (caps & WL_SEAT_CAPABILITY_POINTER) {
        if (!self->pointer_) {
            self->pointer_ = wl_seat_get_pointer(seat);
            wl_pointer_add_listener(self->pointer_, &pointerListener, self);
        }
    }
}

void AppWindow::seatNameCb(void* data, wl_seat* seat, const char* name) {}

void AppWindow::pointerEnterCb(void* data, wl_pointer* pointer, uint32_t serial,
                               wl_surface* surface, wl_fixed_t sx, wl_fixed_t sy) {
    auto* self = static_cast<AppWindow*>(data);
    self->mouseX_ = wl_fixed_to_int(sx);
    self->mouseY_ = wl_fixed_to_int(sy);
}

void AppWindow::pointerLeaveCb(void* data, wl_pointer* pointer, uint32_t serial,
                               wl_surface* surface) {
    auto* self = static_cast<AppWindow*>(data);
    self->mouseInClose_ = self->mouseInMaximize_ = self->mouseInMinimize_ = false;
}

void AppWindow::pointerMotionCb(void* data, wl_pointer* pointer, uint32_t time,
                                wl_fixed_t sx, wl_fixed_t sy) {
    auto* self = static_cast<AppWindow*>(data);
    int oldX = self->mouseX_, oldY = self->mouseY_;
    self->mouseX_ = wl_fixed_to_int(sx);
    self->mouseY_ = wl_fixed_to_int(sy);

    if (self->draggingWindow_) {
        // Wayland doesn't allow client-side window move easily; 
        // we rely on compositor decorations or leave it to derived class
    }

    self->mouseInClose_ = self->hitTestClose(self->mouseX_, self->mouseY_);
    self->mouseInMaximize_ = self->hitTestMaximize(self->mouseX_, self->mouseY_);
    self->mouseInMinimize_ = self->hitTestMinimize(self->mouseX_, self->mouseY_);

    if (self->onMouseMove(self->mouseX_, self->mouseY_)) {
        self->requestRedraw();
    } else if (self->mouseInClose_ || self->mouseInMaximize_ || self->mouseInMinimize_) {
        self->requestRedraw();
    }
}

void AppWindow::pointerButtonCb(void* data, wl_pointer* pointer, uint32_t serial,
                                uint32_t time, uint32_t button, uint32_t state) {
    auto* self = static_cast<AppWindow*>(data);
    int btn = (button == 272) ? 0 : (button == 273) ? 1 : 2;
    bool pressed = (state == WL_POINTER_BUTTON_STATE_PRESSED);

    if (pressed) {
        if (self->hitTestClose(self->mouseX_, self->mouseY_)) {
            self->requestClose(); return;
        }
        if (self->hitTestMaximize(self->mouseX_, self->mouseY_)) {
            if (self->state_ == WindowState::Maximized)
                xdg_toplevel_unset_maximized(self->xdgToplevel_);
            else
                xdg_toplevel_set_maximized(self->xdgToplevel_);
            return;
        }
        if (self->hitTestMinimize(self->mouseX_, self->mouseY_)) {
            xdg_toplevel_set_minimized(self->xdgToplevel_);
            return;
        }
        self->mousePressed_ = true;
        if (self->onMouseDown(self->mouseX_, self->mouseY_, btn)) {
            self->requestRedraw();
        }
    } else {
        self->mousePressed_ = false;
        if (self->onMouseUp(self->mouseX_, self->mouseY_, btn)) {
            self->requestRedraw();
        }
    }
}

void AppWindow::pointerAxisCb(void* data, wl_pointer* pointer, uint32_t time,
                              uint32_t axis, wl_fixed_t value) {
    auto* self = static_cast<AppWindow*>(data);
    int delta = wl_fixed_to_int(value);
    if (axis == WL_POINTER_AXIS_VERTICAL_SCROLL) {
        if (self->onMouseScroll(0, -delta)) self->requestRedraw();
    } else {
        if (self->onMouseScroll(delta, 0)) self->requestRedraw();
    }
}

void AppWindow::pointerFrameCb(void* data, wl_pointer* pointer) {}
void AppWindow::pointerAxisSourceCb(void* data, wl_pointer* pointer, uint32_t axis_source) {}
void AppWindow::pointerAxisStopCb(void* data, wl_pointer* pointer, uint32_t time, uint32_t axis) {}
void AppWindow::pointerAxisDiscreteCb(void* data, wl_pointer* pointer, uint32_t axis, int32_t discrete) {}

void AppWindow::bufferReleaseCb(void* data, wl_buffer* buffer) {
    // Buffer reuse could be implemented here
}

} // namespace agro
