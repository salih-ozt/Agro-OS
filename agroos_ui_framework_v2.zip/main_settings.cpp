#include "ui/settings/settings_app.h"
#include <cstdio>

int main(int argc, char** argv) {
    printf("[AgroOS] Settings starting...\n");
    agro::SettingsApp app;
    if (!app.initialize()) {
        fprintf(stderr, "Failed to initialize Settings\n");
        return 1;
    }
    app.runEventLoop();
    printf("[AgroOS] Settings exiting.\n");
    return 0;
}
